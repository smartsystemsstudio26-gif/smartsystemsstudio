import React from "react";
import { motion } from "framer-motion";

export default function SectionHeading({
  badge,
  title,
  description,
  align = "center",
  badgeColor = "text-[#00D4FF] border-[#0066FF]/30 bg-[#0066FF]/10",
}) {
  const isCenter = align === "center";

  return (
    <div
      className={`flex flex-col mb-12 select-none ${
        isCenter ? "items-center text-center" : "items-start text-left"
      } max-w-3xl ${isCenter ? "mx-auto" : "mr-auto"}`}
    >
      {badge && (
        <motion.span
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className={`inline-flex items-center px-4 py-1.5 rounded-full border text-xs font-semibold uppercase tracking-widest mb-4 ${badgeColor}`}
        >
          {badge}
        </motion.span>
      )}

      {title && (
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-3xl md:text-5xl font-extrabold tracking-tight text-white mb-4 leading-tight font-sans"
        >
          {title}
        </motion.h2>
      )}

      {description && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-base md:text-lg text-[#AAB0BC] leading-relaxed"
        >
          {description}
        </motion.p>
      )}
    </div>
  );
}
