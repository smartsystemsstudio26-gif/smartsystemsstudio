import React, { useEffect, useState, useRef } from "react";
import { useInView } from "framer-motion";

export default function AnimatedCounter({ target, suffix = "", label, duration = 1.5 }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  useEffect(() => {
    if (!isInView) return;

    let start = 0;
    const end = parseInt(target, 10);
    if (isNaN(end)) {
      setCount(target);
      return;
    }

    if (start === end) return;

    const totalMs = duration * 1000;
    const stepTime = Math.max(Math.floor(totalMs / end), 15);

    const timer = setInterval(() => {
      start += Math.ceil(end / (totalMs / stepTime));
      if (start >= end) {
        clearInterval(timer);
        setCount(end);
      } else {
        setCount(start);
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [isInView, target, duration]);

  return (
    <div ref={ref} className="text-center flex flex-col items-center">
      <div className="text-3xl md:text-4xl font-extrabold tracking-tight text-white mb-1.5 font-mono">
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D4FF] via-[#0066FF] to-[#00FFB3]">
          {count}
        </span>
        <span className="text-[#00FFB3]">{suffix}</span>
      </div>
      <p className="text-xs md:text-sm text-[#AAB0BC] font-medium tracking-wide">
        {label}
      </p>
    </div>
  );
}
