import React from "react";
import PortfolioGallery from "../components/portfolio/PortfolioGallery";

export default function Portfolio() {
  return (
    <div className="min-h-screen pt-24 md:pt-16 pb-32">
      <PortfolioGallery />
    </div>
  );
}
