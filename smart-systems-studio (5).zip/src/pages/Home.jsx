import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Zap, Building2, Monitor, Globe } from "lucide-react";

import StatsSection from "../components/home/StatsSection";
import ServicesPreview from "../components/home/ServicesPreview";
import WhyChooseUs from "../components/home/WhyChooseUs";
import TestimonialsSection from "../components/home/TestimonialsSection";
import CTASection from "../components/home/CTASection";
import GlassCard from "../components/shared/GlassCard";

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Immersive Dark Cosmic Hero Section */}
      <section className="relative pt-32 pb-20 md:py-32 overflow-hidden flex items-center">
        {/* Glow Spheres */}
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full bg-[#0066FF]/10 blur-[150px] -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] rounded-full bg-[#00D4FF]/5 blur-[180px] translate-x-1/2 translate-y-1/2" />

        <div className="relative max-w-7xl mx-auto px-6 w-full z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Headline and Call-To-Actions */}
            <div className="lg:col-span-7 flex flex-col items-start space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#0066FF]/30 bg-[#0066FF]/10 text-[#00D4FF] text-xs font-semibold uppercase tracking-wider"
              >
                <Zap className="w-3.5 h-3.5 fill-[#00D4FF]" /> Smart Systems Studio
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-none font-sans"
              >
                Launch, Automate &amp; <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#0066FF] via-[#00D4FF] to-[#00FFB3]">
                  Scale Your Business
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-base sm:text-lg text-[#AAB0BC] max-w-xl leading-relaxed"
              >
                Empowering entrepreneurs and organization leaders across Africa with professional digital solutions. We handle official CIPC company filings, custom website design, specialized management systems, and premium business software.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="flex flex-wrap items-center gap-4 w-full sm:w-auto"
              >
                <Link
                  to="/services"
                  className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#0066FF] to-[#00D4FF] text-white font-bold text-sm tracking-wide shadow-lg shadow-[#0066FF]/20 hover:shadow-[#00D4FF]/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  Explore Services
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  to="/contact"
                  className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white border border-white/10 hover:border-white/25 font-bold text-sm tracking-wide transition-all flex items-center justify-center gap-2"
                >
                  Contact Us
                </Link>
              </motion.div>
            </div>

            {/* Right Column: Dynamic Core Service Visualizers */}
            <div className="lg:col-span-5 h-full w-full">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="w-full"
              >
                <GlassCard glowColor="rgba(0,102,255,0.15)" className="p-6 w-full flex flex-col gap-6">
                  {/* Glowing header badge inside card */}
                  <div className="flex items-center justify-between pb-3 border-b border-white/5">
                    <span className="text-xs font-semibold text-[#AAB0BC] uppercase tracking-wider">Premium Offerings</span>
                    <span className="w-2 h-2 rounded-full bg-[#00FFB3] animate-pulse" />
                  </div>

                  {/* Micro list of top features */}
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-[#0066FF]/10 flex items-center justify-center border border-[#0066FF]/20 flex-shrink-0">
                        <Building2 className="w-5 h-5 text-[#0066FF]" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">CIPC Registration</h3>
                        <p className="text-xs text-[#AAB0BC] mt-0.5">Quickly register ready-to-trade companies, SARS Tax setup, and BEE affidavits.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-[#00D4FF]/10 flex items-center justify-center border border-[#00D4FF]/20 flex-shrink-0">
                        <Globe className="w-5 h-5 text-[#00D4FF]" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">Systems &amp; Websites</h3>
                        <p className="text-xs text-[#AAB0BC] mt-0.5">Ultra-fast web platforms specialized for Churches, Schools, and businesses.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-[#00FFB3]/10 flex items-center justify-center border border-[#00FFB3]/20 flex-shrink-0">
                        <Monitor className="w-5 h-5 text-[#00FFB3]" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">Management Software</h3>
                        <p className="text-xs text-[#AAB0BC] mt-0.5">Bespoke POS software, automation systems, and high performance databases.</p>
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <StatsSection />

      {/* Services Preview Grid */}
      <ServicesPreview />

      {/* Core Strengths Section */}
      <WhyChooseUs />

      {/* Client Endorsements Section */}
      <TestimonialsSection />

      {/* Call To Action Banner */}
      <CTASection />
    </div>
  );
}
