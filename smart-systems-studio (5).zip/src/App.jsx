import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";

import FloatingNav from "./components/layout/FloatingNav";
import Footer from "./components/layout/Footer";

// Page imports
import Home from "./pages/Home";
import Services from "./pages/Services";
import Portfolio from "./pages/Portfolio";
import About from "./pages/About";
import Contact from "./pages/Contact";
import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";

export default function App() {
  const location = useLocation();

  // Hide Nav and Footer on Admin sections
  const isAdminPage = location.pathname.startsWith("/admin-dashboard") || location.pathname.startsWith("/admin-login");

  return (
    <div className="bg-[#0B1221] text-white min-h-screen selection:bg-[#0066FF]/30 selection:text-white">
      {!isAdminPage && <FloatingNav />}
      
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          {/* Fallback back to home */}
          <Route path="*" element={<Home />} />
        </Routes>
      </AnimatePresence>

      {!isAdminPage && <Footer />}
    </div>
  );
}
