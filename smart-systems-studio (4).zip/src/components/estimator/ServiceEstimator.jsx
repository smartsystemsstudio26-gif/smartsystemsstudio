import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Building2, Globe, Monitor, Palette, Award, Cloud, ArrowRight, Sparkles,
} from "lucide-react";

function InteractiveParticles() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let animationFrameId;

    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const particles = [];
    // Adjust density based on screen size
    const count = width < 768 ? 20 : 50;

    class Particle {
      constructor() {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = (Math.random() - 0.5) * 0.5;
        this.vy = (Math.random() - 0.5) * 0.5;
        this.radius = Math.random() * 2 + 1;
      }

      update() {
        this.x += this.vx;
        this.y += this.vy;

        if (this.x < 0 || this.x > width) this.vx = -this.vx;
        if (this.y < 0 || this.y > height) this.vy = -this.vy;
      }

      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(0, 212, 255, 0.25)";
        ctx.fill();
      }
    }

    for (let i = 0; i < count; i++) {
      particles.push(new Particle());
    }

    const mouse = { x: null, y: null, radius: 150 };

    const handleMouseMove = (e) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    };

    const handleMouseLeave = () => {
      mouse.x = null;
      mouse.y = null;
    };

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };

    // Listen to container mousemove
    const parent = canvas.parentElement;
    if (parent) {
      parent.addEventListener("mousemove", handleMouseMove);
      parent.addEventListener("mouseleave", handleMouseLeave);
    }
    window.addEventListener("resize", handleResize);

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw and connect particles
      for (let i = 0; i < particles.length; i++) {
        const p1 = particles[i];
        p1.update();
        p1.draw();

        // Mouse interaction details
        if (mouse.x !== null && mouse.y !== null) {
          const dx = mouse.x - p1.x;
          const dy = mouse.y - p1.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < mouse.radius) {
            const force = (mouse.radius - dist) / mouse.radius;
            // Gently nudge particles away/pull them based on aesthetic choice
            p1.x -= dx * force * 0.02;
            p1.y -= dy * force * 0.02;
          }
        }

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          // Connect particles within an interactive threshold
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(0, 212, 255, ${0.1 * (1 - dist / 120)})`;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (parent) {
        parent.removeEventListener("mousemove", handleMouseMove);
        parent.removeEventListener("mouseleave", handleMouseLeave);
      }
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-0"
    />
  );
}

const services = [
  {
    id: "business_registration",
    label: "Business & CIPC Registration",
    price: "R499",
    icon: Building2,
    description: "Fast company registration, complete official CIPC compliance, SARS tax setups, and corporate startup consulting.",
    href: "/contact",
  },
  {
    id: "website",
    label: "Websites & Systems Development",
    price: "R1,999",
    icon: Globe,
    description: "Premium, ultra-responsive corporate websites, including specialized systems for Church and School websites with user portals.",
    href: "/contact",
  },
  {
    id: "software",
    label: "School, Church & Business Software",
    price: "R3,499",
    icon: Monitor,
    description: "Custom management software (featuring comprehensive Church and School management systems), next-gen Cloud POS, and tailored CRMs.",
    href: "/contact",
  },
  {
    id: "design",
    label: "Graphic Design",
    price: "R199",
    icon: Palette,
    description: "Breathtaking custom identity packages, logo designs, company profiles, and marketing collateral.",
    href: "/contact",
  },
  {
    id: "bee",
    label: "BEE Certificates",
    price: "R349",
    icon: Award,
    description: "Speedy BEE affidavits, compliance certificates, and expert transformation consulting.",
    href: "/contact",
  },
  {
    id: "digital",
    label: "Digital Solutions",
    price: "R899",
    icon: Cloud,
    description: "Custom server-less systems, automated workflows, and robust cloud services integrations.",
    href: "/contact",
  },
];

function ServiceShowcaseCard({ service, index }) {
  const cardRef = useRef(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glowX, setGlowX] = useState(50);
  const [glowY, setGlowY] = useState(50);

  const colors = {
    business_registration: "#0066FF",
    website: "#00D4FF",
    software: "#9D4EDD",
    design: "#FF007A",
    bee: "#FFB703",
    digital: "#00FFB3",
  };
  const themeColor = colors[service.id] || "#0066FF";

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    setRotateX(((y - centerY) / centerY) * -10);
    setRotateY(((x - centerX) / centerX) * 10);
    setGlowX((x / rect.width) * 100);
    setGlowY((y / rect.height) * 100);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setGlowX(50);
    setGlowY(50);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className="group perspective-[1000px] hover:z-20 w-full"
    >
      <motion.div
        animate={{
          y: [0, -6, 0],
        }}
        transition={{
          y: {
            repeat: Infinity,
            duration: 4.5,
            ease: "easeInOut",
            delay: index * 0.15,
          }
        }}
        whileHover={{
          y: -14,
          scale: 1.04,
          transition: { duration: 0.3, ease: "easeOut" }
        }}
        className="w-full h-full relative"
      >
        <Link
          to={service.href}
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="glass rounded-2xl p-6 relative overflow-hidden transition-all duration-200 ease-out cursor-pointer h-full w-full flex flex-col border text-left border-white/10 hover:border-[#00D4FF]/30 hover:shadow-[0_15px_35px_rgba(0,212,255,0.12)]"
          style={{
            transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
            transformStyle: "preserve-3d",
            display: "flex",
          }}
        >
          {/* Moving glow overlay */}
          <div
            className="absolute inset-0 pointer-events-none transition-opacity duration-300 opacity-0 group-hover:opacity-100 rounded-2xl"
            style={{
              background: `radial-gradient(circle at ${glowX}% ${glowY}%, ${themeColor}18 0%, transparent 60%)`,
            }}
          />

          <div className="relative z-10 flex-grow w-full flex flex-col" style={{ transform: "translateZ(25px)", transformStyle: "preserve-3d" }}>
            <div className="flex justify-between items-start mb-4 w-full">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center bg-white/[0.03] transition-transform duration-300 group-hover:scale-110"
                style={{ border: `1px solid ${themeColor}20` }}
              >
                <service.icon
                  className="w-5.5 h-5.5 transition-colors duration-300"
                  style={{ color: themeColor }}
                />
              </div>
            </div>

            <div className="mb-2">
              <h4 className="text-base font-bold text-white mb-1.5">{service.label}</h4>
              <div className="flex items-center gap-1.5 py-0.5 px-2 rounded bg-white/[0.03] border border-white/5 w-fit">
                <span className="text-[10px] text-[#AAB0BC] tracking-wider uppercase font-medium">Starting from</span>
                <span className="text-xs font-bold" style={{ color: themeColor }}>{service.price}</span>
              </div>
            </div>
            <p className="text-xs text-[#AAB0BC] leading-relaxed mb-4 flex-grow">{service.description}</p>
            
            <div className="mt-auto pt-3 border-t border-white/5 flex items-center gap-1.5 text-xs text-[#00D4FF] font-medium group-hover:text-[#00FFB3] transition-colors">
              <span>Select Service for Project</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </div>
          </div>
        </Link>
      </motion.div>
    </motion.div>
  );
}

export default function ServiceEstimator() {
  return (
    <section className="relative py-24 overflow-hidden">
      {/* Subtle, interactive particle animation background */}
      <InteractiveParticles />

      <div className="absolute top-0 left-0 w-[500px] h-[500px] rounded-full bg-[#00D4FF]/2 blur-[120px]" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] rounded-full bg-[#00FFB3]/2 blur-[100px]" />

      <div className="max-w-6xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-light mb-6">
            <div className="w-1.5 h-1.5 rounded-full bg-[#00FFB3]" />
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#00D4FF]">
              Start Working Together
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight mb-5">
            Build Your <span className="gradient-text">Custom Solution</span>
          </h2>
          <p className="text-base md:text-lg text-[#AAB0BC] max-w-xl mx-auto">
            Choose your custom combination of services. Select one or more solutions directly on our contact request page.
          </p>
        </motion.div>

        {/* Step Content */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
          {services.map((service, idx) => (
            <ServiceShowcaseCard
              key={service.id}
              service={service}
              index={idx}
            />
          ))}
        </div>

        {/* Main call to action CTA */}
        <div className="text-center mt-12">
          <Link to="/contact">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="px-8 py-4 bg-[#0066FF] hover:bg-[#0052cc] text-white rounded-xl font-bold text-sm inline-flex items-center gap-2 shadow-[0_20px_40px_rgba(0,102,255,0.25)] transition-all"
            >
              Configure Custom Package
              <Sparkles className="w-4 h-4 text-[#00FFB3]" />
            </motion.button>
          </Link>
        </div>
      </div>
    </section>
  );
}
