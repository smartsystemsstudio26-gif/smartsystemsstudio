import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ExternalLink, ChevronLeft, ChevronRight, Search } from "lucide-react";

const categories = [
  { id: "all", label: "All Projects" },
  { id: "registration", label: "Business Registration" },
  { id: "websites", label: "Websites" },
  { id: "software", label: "Software" },
  { id: "design", label: "Graphic Design" },
  { id: "certificates", label: "Certificates" },
];

const projects = [
  {
    id: 1,
    title: "CIPC Company Registration",
    category: "registration",
    description: "Full PTY company registration with CIPC compliance, tax number, and all statutory documents.",
    image: "https://media.base44.com/images/public/6a2c1a6b852e53957d49448d/aaa5038da_generated_image.png",
    tags: ["CIPC", "PTY", "Compliance"],
    gradient: "from-blue-600/80 to-cyan-500/80",
  },
  {
    id: 2,
    title: "BEE Certificate — Level 1",
    category: "certificates",
    description: "Broad-Based Black Economic Empowerment Level 1 certificate for government tender compliance.",
    image: "https://media.base44.com/images/public/6a2c1a6b852e53957d49448d/533809f52_generated_image.png",
    tags: ["BEE", "Level 1", "Tender"],
    gradient: "from-emerald-600/80 to-teal-500/80",
  },
  {
    id: 3,
    title: "E-Commerce Platform",
    category: "websites",
    description: "Full-featured online store with payment integration, inventory management, and admin dashboard.",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&q=80",
    tags: ["Shopify", "Payments", "Inventory"],
    gradient: "from-violet-600/80 to-purple-500/80",
  },
  {
    id: 4,
    title: "POS & Inventory System",
    category: "software",
    description: "Complete point-of-sale system with real-time inventory tracking, sales reports, and barcode scanning.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80",
    tags: ["POS", "Inventory", "Reports"],
    gradient: "from-orange-600/80 to-amber-500/80",
  },
  {
    id: 5,
    title: "Corporate Brand Identity",
    category: "design",
    description: "Complete branding package including logo, business cards, letterheads, and social media kit.",
    image: "https://images.unsplash.com/photo-1626785774625-ddcddc3445e0?w=800&q=80",
    tags: ["Logo", "Branding", "Print"],
    gradient: "from-pink-600/80 to-rose-500/80",
  },
  {
    id: 6,
    title: "Business Registration — Sole Prop",
    category: "registration",
    description: "Sole proprietor registration with SARS tax compliance, business bank account setup guidance.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80",
    tags: ["SARS", "Sole Prop", "Tax"],
    gradient: "from-blue-700/80 to-indigo-500/80",
  },
  {
    id: 7,
    title: "CRM & Client Management",
    category: "software",
    description: "Custom CRM system with lead tracking, client portal, automated follow-ups, and analytics.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80",
    tags: ["CRM", "Automation", "Analytics"],
    gradient: "from-cyan-600/80 to-blue-500/80",
  },
  {
    id: 8,
    title: "Business Website — Law Firm",
    category: "websites",
    description: "Professional multi-page website with case management integration, appointment booking, and SEO.",
    image: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=800&q=80",
    tags: ["WordPress", "SEO", "Booking"],
    gradient: "from-slate-700/80 to-gray-500/80",
  },
  {
    id: 9,
    title: "BEE Affidavit — EME",
    category: "certificates",
    description: "Exempted Micro Enterprise BEE affidavit for small business compliance and supplier registration.",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&q=80",
    tags: ["EME", "Affidavit", "Supplier"],
    gradient: "from-green-600/80 to-emerald-500/80",
  },
];

function PortfolioCard({ project, index, onClick }) {
  const cardRef = useRef(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [glow, setGlow] = useState({ x: 50, y: 50 });

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    setTilt({ x: y * -12, y: x * 12 });
    setGlow({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
    setGlow({ x: 50, y: 50 });
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="perspective-[1000px] hover:z-20"
    >
      <motion.div
        animate={{
          y: [0, -6, 0],
        }}
        transition={{
          y: {
            repeat: Infinity,
            duration: 4.5,
            ease: "easeInOut",
            delay: index * 0.15,
          }
        }}
        whileHover={{
          y: -14,
          scale: 1.04,
          transition: { duration: 0.3, ease: "easeOut" }
        }}
        className="w-full h-full relative"
      >
        <div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          onClick={() => onClick(project)}
          style={{
            transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
            transformStyle: "preserve-3d",
          }}
          className="relative group cursor-pointer rounded-2xl overflow-hidden border border-white/10 bg-white/[0.02] h-full flex flex-col transition-all duration-200 ease-out hover:shadow-[0_20px_45px_rgba(0,102,255,0.22)] hover:border-[#00D4FF]/30"
        >
          {/* Glow overlay */}
          <div
            className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10"
            style={{
              background: `radial-gradient(circle at ${glow.x}% ${glow.y}%, rgba(0,212,255,0.2) 0%, transparent 50%)`,
            }}
          />

          {/* Image */}
          <div className="aspect-[4/3] overflow-hidden" style={{ transform: "translateZ(10px)" }}>
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
            />
          </div>

          {/* Gradient overlay */}
          <div className={`absolute inset-0 bg-gradient-to-t ${project.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-400`} />

          {/* Info overlay */}
          <div className="absolute inset-0 flex flex-col justify-end p-5 opacity-0 group-hover:opacity-100 transition-all duration-400 translate-y-2 group-hover:translate-y-0 z-20" style={{ transform: "translateZ(25px)" }}>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {project.tags.map((tag) => (
                <span key={tag} className="px-2 py-0.5 rounded-md bg-white/20 text-[10px] font-medium text-white backdrop-blur-sm">
                  {tag}
                </span>
              ))}
            </div>
            <h3 className="text-base font-bold text-white mb-1">{project.title}</h3>
            <p className="text-xs text-white/80 line-clamp-2">{project.description}</p>
          </div>

          {/* Bottom info bar (visible always) */}
          <div className="p-4 group-hover:opacity-0 transition-opacity duration-200 mt-auto" style={{ transform: "translateZ(15px)" }}>
            <span className="text-xs font-medium text-[#AAB0BC] uppercase tracking-wider">
              {categories.find(c => c.id === project.category)?.label || project.category}
            </span>
            <h3 className="text-sm font-bold text-white mt-1 line-clamp-1">{project.title}</h3>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function Lightbox({ project, onClose, onPrev, onNext, hasPrev, hasNext }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md p-4"
      onClick={onClose}
    >
      {/* Close */}
      <button onClick={onClose} className="absolute top-6 right-6 p-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors z-20">
        <X className="w-5 h-5 text-white" />
      </button>

      {/* Navigation */}
      {hasPrev && (
        <button
          onClick={(e) => { e.stopPropagation(); onPrev(); }}
          className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-xl bg-white/10 hover:bg-white/20 transition-colors z-20"
        >
          <ChevronLeft className="w-6 h-6 text-white" />
        </button>
      )}
      {hasNext && (
        <button
          onClick={(e) => { e.stopPropagation(); onNext(); }}
          className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-xl bg-white/10 hover:bg-white/20 transition-colors z-20"
        >
          <ChevronRight className="w-6 h-6 text-white" />
        </button>
      )}

      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative max-w-5xl w-full max-h-[90vh] flex flex-col md:flex-row gap-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Image */}
        <div className="flex-1 rounded-2xl overflow-hidden border border-white/10">
          <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
        </div>

        {/* Details */}
        <div className="md:w-80 flex flex-col justify-center">
          <div className="flex flex-wrap gap-1.5 mb-4">
            {project.tags.map((tag) => (
              <span key={tag} className="px-2.5 py-1 rounded-lg bg-[#0066FF]/20 text-xs font-medium text-[#00D4FF]">
                {tag}
              </span>
            ))}
          </div>
          <h2 className="text-2xl font-extrabold text-white mb-3">{project.title}</h2>
          <p className="text-sm text-[#AAB0BC] leading-relaxed">{project.description}</p>

          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="mt-6 px-5 py-2.5 bg-[#0066FF] rounded-xl text-sm font-semibold text-white flex items-center gap-2 self-start"
          >
            <ExternalLink className="w-4 h-4" />
            View Project
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function PortfolioGallery() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [lightboxProject, setLightboxProject] = useState(null);

  const filteredProjects = activeCategory === "all"
    ? projects
    : projects.filter(p => p.category === activeCategory);

  const currentIndex = lightboxProject ? filteredProjects.indexOf(lightboxProject) : -1;

  const openLightbox = (project) => setLightboxProject(project);
  const closeLightbox = () => setLightboxProject(null);
  const goToPrev = () => {
    if (currentIndex > 0) setLightboxProject(filteredProjects[currentIndex - 1]);
  };
  const goToNext = () => {
    if (currentIndex < filteredProjects.length - 1) setLightboxProject(filteredProjects[currentIndex + 1]);
  };

  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-[#0066FF]/4 blur-[120px]" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-[#00FFB3]/3 blur-[100px]" />

      <div className="max-w-7xl mx-auto px-6 relative">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-light mb-6">
            <div className="w-1.5 h-1.5 rounded-full bg-[#00FFB3]" />
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#00D4FF]">
              Our Work
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight mb-5">
            Featured <span className="gradient-text">Projects</span>
          </h2>
          <p className="text-base md:text-lg text-[#AAB0BC] max-w-xl mx-auto">
            Explore our portfolio of successful projects across business registration, websites, software, and design.
          </p>
        </motion.div>

        {/* Category filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                activeCategory === cat.id
                  ? "bg-[#0066FF] text-white shadow-[0_0_15px_rgba(0,102,255,0.3)]"
                  : "bg-white/5 text-[#AAB0BC] hover:bg-white/10 hover:text-white"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Grid */}
        <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, index) => (
              <PortfolioCard
                key={project.id}
                project={project}
                index={index}
                onClick={openLightbox}
              />
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Empty state */}
        {filteredProjects.length === 0 && (
          <div className="text-center py-20">
            <Search className="w-12 h-12 text-[#AAB0BC]/30 mx-auto mb-4" />
            <p className="text-[#AAB0BC]">No projects found in this category.</p>
          </div>
        )}
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxProject && (
          <Lightbox
            project={lightboxProject}
            onClose={closeLightbox}
            onPrev={goToPrev}
            onNext={goToNext}
            hasPrev={currentIndex > 0}
            hasNext={currentIndex < filteredProjects.length - 1}
          />
        )}
      </AnimatePresence>
    </section>
  );
}