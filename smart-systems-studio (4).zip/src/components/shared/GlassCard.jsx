import React, { useRef, useState } from "react";
import { motion } from "framer-motion";

export default function GlassCard({ children, className = "", delay = 0, glowColor = "rgba(0,102,255,0.08)", noPadding = false }) {
  const cardRef = useRef(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glowX, setGlowX] = useState(50);
  const [glowY, setGlowY] = useState(50);

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    setRotateX(((y - centerY) / centerY) * -10); // slightly enhanced for better 3D feedback
    setRotateY(((x - centerX) / centerX) * 10);
    setGlowX((x / rect.width) * 100);
    setGlowY((y / rect.height) * 100);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setGlowX(50);
    setGlowY(50);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.6, delay }}
      className={`group perspective-[1000px] hover:z-20 ${className}`}
    >
      <motion.div
        animate={{
          y: [0, -6, 0],
        }}
        transition={{
          y: {
            repeat: Infinity,
            duration: 4.5,
            ease: "easeInOut",
            delay: delay * 1.5,
          }
        }}
        whileHover={{
          y: -14,
          scale: 1.04,
          transition: { duration: 0.3, ease: "easeOut" }
        }}
        className="w-full h-full relative"
      >
        <div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className={`glass rounded-2xl ${noPadding ? "" : "p-6"} animate-border-glow relative overflow-hidden transition-all duration-200 ease-out hover:shadow-[0_20px_45px_rgba(0,102,255,0.22)] border-white/10 hover:border-[#00D4FF]/30 h-full flex flex-col`}
          style={{
            transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
            transformStyle: "preserve-3d",
          }}
        >
          {/* Moving glow overlay */}
          <div
            className="absolute inset-0 pointer-events-none transition-opacity duration-300 opacity-0 group-hover:opacity-100 rounded-2xl"
            style={{
              background: `radial-gradient(circle at ${glowX}% ${glowY}%, ${glowColor} 0%, transparent 60%)`,
            }}
          />
          <div className="relative z-10 flex-1 flex flex-col" style={{ transform: "translateZ(25px)", transformStyle: "preserve-3d" }}>
            {children}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}