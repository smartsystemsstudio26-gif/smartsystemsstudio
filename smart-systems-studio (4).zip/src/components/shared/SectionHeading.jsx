import React from "react";
import { motion } from "framer-motion";

export default function SectionHeading({ badge, title, description }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.7 }}
      className="text-center max-w-3xl mx-auto mb-16"
    >
      {badge && (
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-light mb-6">
          <div className="w-1.5 h-1.5 rounded-full bg-[#00FFB3]" />
          <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#00D4FF]">
            {badge}
          </span>
        </div>
      )}
      <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight mb-5">
        {title}
      </h2>
      {description && (
        <p className="text-base md:text-lg text-[#AAB0BC] leading-relaxed">
          {description}
        </p>
      )}
    </motion.div>
  );
}