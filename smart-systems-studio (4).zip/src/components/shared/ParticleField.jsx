import React, { useRef, useEffect } from "react";
import * as THREE from "three";

export default function ParticleField({ className = "", density = 150, colors = [0x0066ff, 0x00d4ff, 0x00ffb3] }) {
  const containerRef = useRef(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 100);
    camera.position.z = 10;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Main particle cloud
    const count = density;
    const positions = new Float32Array(count * 3);
    const colorArr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 20;
      const color = new THREE.Color(colors[Math.floor(Math.random() * colors.length)]);
      colorArr[i * 3] = color.r;
      colorArr[i * 3 + 1] = color.g;
      colorArr[i * 3 + 2] = color.b;
    }
    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    particleGeo.setAttribute("color", new THREE.BufferAttribute(colorArr, 3));
    const particleMat = new THREE.PointsMaterial({
      size: 0.035,
      vertexColors: true,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Orbiting ring particles
    const ringCount = 80;
    const ringPositions = new Float32Array(ringCount * 3);
    for (let i = 0; i < ringCount; i++) {
      const angle = (i / ringCount) * Math.PI * 2;
      const radius = 3.5 + Math.sin(i * 3) * 0.3;
      ringPositions[i * 3] = Math.cos(angle) * radius;
      ringPositions[i * 3 + 1] = Math.sin(angle) * radius * 0.4;
      ringPositions[i * 3 + 2] = Math.sin(i * 3) * 0.5;
    }
    const ringGeo = new THREE.BufferGeometry();
    ringGeo.setAttribute("position", new THREE.BufferAttribute(ringPositions, 3));
    const ringMat = new THREE.PointsMaterial({
      size: 0.025,
      color: 0x00d4ff,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const ringParticles = new THREE.Points(ringGeo, ringMat);
    scene.add(ringParticles);

    // Large wireframe sphere
    const outerGeo = new THREE.IcosahedronGeometry(2.5, 1);
    const outerMat = new THREE.MeshBasicMaterial({
      color: 0x0066ff,
      wireframe: true,
      transparent: true,
      opacity: 0.08,
    });
    const outer = new THREE.Mesh(outerGeo, outerMat);
    scene.add(outer);

    // Medium wireframe
    const midGeo = new THREE.IcosahedronGeometry(3.2, 2);
    const midMat = new THREE.MeshBasicMaterial({
      color: 0x00d4ff,
      wireframe: true,
      transparent: true,
      opacity: 0.04,
    });
    const mid = new THREE.Mesh(midGeo, midMat);
    scene.add(mid);

    let mouseX = 0, mouseY = 0;
    const onMouseMove = (e) => {
      mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    };
    window.addEventListener("mousemove", onMouseMove);

    let animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = performance.now() * 0.001;

      particles.rotation.y = t * 0.03 + mouseX * 0.1;
      particles.rotation.x = Math.sin(t * 0.15) * 0.15 + mouseY * 0.1;

      ringParticles.rotation.y = t * 0.2;
      ringParticles.rotation.z = Math.cos(t * 0.12) * 0.2;

      outer.rotation.y = t * 0.1 + mouseX * 0.2;
      outer.rotation.x = Math.sin(t * 0.1) * 0.15 + mouseY * 0.2;

      mid.rotation.y = -t * 0.15;
      mid.rotation.z = Math.cos(t * 0.08) * 0.1;

      particleMat.opacity = 0.5 + Math.sin(t * 0.5) * 0.2;

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("mousemove", onMouseMove);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [density]);

  return <div ref={containerRef} className={`absolute inset-0 ${className}`} aria-label="Interactive 3D particle visualization" />;
}