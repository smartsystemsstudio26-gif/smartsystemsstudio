import React, { useRef, useEffect } from "react";
import * as THREE from "three";

export default function Logo3D({ className = "", size = 120 }) {
  const containerRef = useRef(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.z = 5;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    // Hexagon shape
    const hexShape = new THREE.Shape();
    const hexRadius = 1.2;
    for (let i = 0; i < 6; i++) {
      const angle = (Math.PI / 3) * i - Math.PI / 6;
      const x = Math.cos(angle) * hexRadius;
      const y = Math.sin(angle) * hexRadius;
      if (i === 0) hexShape.moveTo(x, y);
      else hexShape.lineTo(x, y);
    }
    hexShape.closePath();

    // Extrude hexagon
    const extrudeSettings = { depth: 0.15, bevelEnabled: true, bevelThickness: 0.05, bevelSize: 0.05, bevelSegments: 3 };
    const hexGeo = new THREE.ExtrudeGeometry(hexShape, extrudeSettings);
    const hexMat = new THREE.MeshPhysicalMaterial({
      color: 0x0066ff,
      metalness: 0.1,
      roughness: 0.2,
      clearcoat: 0.3,
      clearcoatRoughness: 0.2,
      transparent: true,
      opacity: 0.85,
      emissive: 0x001a4d,
      emissiveIntensity: 0.4,
    });
    const hexMesh = new THREE.Mesh(hexGeo, hexMat);
    scene.add(hexMesh);

    // Edge glow
    const edgeGeo = new THREE.EdgesGeometry(hexGeo);
    const edgeMat = new THREE.LineBasicMaterial({ color: 0x00d4ff, transparent: true, opacity: 0.6 });
    const edgeLine = new THREE.LineSegments(edgeGeo, edgeMat);
    hexMesh.add(edgeLine);

    // Outer ring
    const ringGeo = new THREE.TorusGeometry(1.35, 0.02, 16, 48);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x00ffb3, transparent: true, opacity: 0.5 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    scene.add(ring);

    // Second outer ring
    const ring2Geo = new THREE.TorusGeometry(1.5, 0.015, 16, 48);
    const ring2Mat = new THREE.MeshBasicMaterial({ color: 0x00d4ff, transparent: true, opacity: 0.25 });
    const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
    ring2.rotation.x = Math.PI / 2;
    scene.add(ring2);

    // Floating particles around logo
    const particleCount = 60;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;
      const r = 1.6 + Math.random() * 0.5;
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi) - 0.075;
    }
    particleGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({
      size: 0.025,
      color: 0x00d4ff,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Inner glow disc
    const discGeo = new THREE.CircleGeometry(1.0, 32);
    const discMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uColor1: { value: new THREE.Color(0x0066ff) },
        uColor2: { value: new THREE.Color(0x00ffb3) },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        uniform float uTime;
        uniform vec3 uColor1;
        uniform vec3 uColor2;
        void main() {
          float dist = length(vUv - 0.5) * 2.0;
          float alpha = smoothstep(1.0, 0.0, dist) * 0.15;
          alpha *= 0.6 + 0.4 * sin(uTime * 2.0 + dist * 6.0);
          vec3 color = mix(uColor1, uColor2, sin(uTime + dist * 4.0) * 0.5 + 0.5);
          gl_FragColor = vec4(color, alpha);
        }
      `,
      transparent: true,
      depthWrite: false,
    });
    const disc = new THREE.Mesh(discGeo, discMat);
    disc.position.z = 0.081;
    scene.add(disc);

    // Scene background particles
    const bgParticleCount = 40;
    const bgGeo = new THREE.BufferGeometry();
    const bgPositions = new Float32Array(bgParticleCount * 3);
    for (let i = 0; i < bgParticleCount; i++) {
      bgPositions[i * 3] = (Math.random() - 0.5) * 6;
      bgPositions[i * 3 + 1] = (Math.random() - 0.5) * 6;
      bgPositions[i * 3 + 2] = (Math.random() - 0.5) * 4 - 1;
    }
    bgGeo.setAttribute("position", new THREE.BufferAttribute(bgPositions, 3));
    const bgMat = new THREE.PointsMaterial({
      size: 0.02,
      color: 0x0066ff,
      transparent: true,
      opacity: 0.4,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const bgParticles = new THREE.Points(bgGeo, bgMat);
    scene.add(bgParticles);

    // Mouse interaction
    let mouseX = 0, mouseY = 0;
    const onMouseMove = (e) => {
      mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    };
    window.addEventListener("mousemove", onMouseMove);

    let animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = performance.now() * 0.001;

      // Smooth mouse follow
      const targetX = mouseX * 0.15;
      const targetY = mouseY * 0.15;

      hexMesh.rotation.y += (targetX - hexMesh.rotation.y) * 0.05;
      hexMesh.rotation.x += (targetY - hexMesh.rotation.x) * 0.05;
      hexMesh.rotation.z = Math.sin(t * 0.3) * 0.05;

      ring.rotation.z = t * 0.4;
      ring.rotation.x = Math.sin(t * 0.5) * 0.3;
      ring.rotation.y = Math.cos(t * 0.4) * 0.3;

      ring2.rotation.z = -t * 0.3;
      ring2.rotation.x = Math.PI / 2 + Math.cos(t * 0.4) * 0.2;

      particles.rotation.y = t * 0.2;
      particles.rotation.x = Math.sin(t * 0.3) * 0.3;

      bgParticles.rotation.y = t * 0.1;
      bgParticles.rotation.x = Math.sin(t * 0.2) * 0.1;

      disc.material.uniforms.uTime.value = t;
      edgeMat.opacity = 0.4 + Math.sin(t * 1.5) * 0.2;

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("mousemove", onMouseMove);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className={className}
      style={{ width: size, height: size }}
      aria-label="Smart Systems Studio 3D animated logo"
    />
  );
}