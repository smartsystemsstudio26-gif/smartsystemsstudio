import React, { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Play, ShieldCheck, FileText, Globe, Cpu, Palette, Sliders } from "lucide-react";

const trustData = [
  { label: "REGISTRY_STATUS", value: "ACTIVE" },
  { label: "SITES_DEPLOYED", value: "452" },
  { label: "UPTIME", value: "99.9%" },
  { label: "BUSINESSES_SUPPORTED", value: "280+" },
  { label: "PROJECTS_COMPLETED", value: "650+" },
  { label: "CLIENT_SATISFACTION", value: "98%" },
];

function GridCoreCanvas({ activeLabel }) {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);

  const nodes = [
    { label: 'CIPC Registry', angle: 0, height: -0.4, color: '#00FFB3', description: 'CIPC South Africa business registrations, startups consulting, & full legal compliance setup.' },
    { label: 'BEE Compliance', angle: (Math.PI * 2) / 6, height: 0.3, color: '#00D4FF', description: 'Level 1 BEE affidavits, fast-track certifications, and compliance assistance.' },
    { label: 'Web Engine', angle: (Math.PI * 2 * 2) / 6, height: -0.1, color: '#0066FF', description: 'High-performance interactive web portals, school platforms, & digital storefronts.' },
    { label: 'POS & ERP Systems', angle: (Math.PI * 2 * 3) / 6, height: 0.5, color: '#00FFB3', description: 'Advanced business automation tools, point-of-sale systems, and smart inventory management.' },
    { label: 'Creative Design', angle: (Math.PI * 2 * 4) / 6, height: -0.6, color: '#a855f7', description: 'Corporate identity systems, logos, high-conversion vector graphics, & profiles.' },
    { label: 'Cloud Automations', angle: (Math.PI * 2 * 5) / 6, height: 0.1, color: '#00D4FF', description: 'Cloud custom systems, secure client portals, and streamlined automation tools.' },
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrame;
    let rotationAngle = 0;

    const handleResize = () => {
      const rect = containerRef.current?.getBoundingClientRect();
      canvas.width = rect?.width || 500;
      canvas.height = rect?.height || 500;
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    const spherePoints = [];
    const bandsCount = 14;
    const pointsPerBand = 18;

    for (let i = 1; i < bandsCount; i++) {
      const theta = (i * Math.PI) / bandsCount;
      const sinTheta = Math.sin(theta);
      const cosTheta = Math.cos(theta);
      for (let j = 0; j < pointsPerBand; j++) {
        const phi = (j * 2 * Math.PI) / pointsPerBand;
        spherePoints.push({
          x: sinTheta * Math.cos(phi),
          y: cosTheta,
          z: sinTheta * Math.sin(phi),
        });
      }
    }

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = Math.min(canvas.width, canvas.height) * 0.35;

      rotationAngle += 0.003;

      // Outer halo
      ctx.strokeStyle = 'rgba(0, 212, 255, 0.04)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * 1.35, 0, Math.PI * 2);
      ctx.stroke();

      // Dashed satellite track
      ctx.setLineDash([4, 12]);
      ctx.strokeStyle = 'rgba(0, 255, 179, 0.12)';
      ctx.beginPath();
      ctx.ellipse(centerX, centerY, radius * 1.5, radius * 0.35, Math.PI / 12, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Globe dots
      for (const p of spherePoints) {
        const cosY = Math.cos(rotationAngle);
        const sinY = Math.sin(rotationAngle);
        const rotX = p.x * cosY - p.z * sinY;
        const rotZ = p.x * sinY + p.z * cosY;
        const perspective = 2.5 / (2.5 + rotZ);
        const x2d = centerX + rotX * radius * perspective;
        const y2d = centerY + p.y * radius * perspective;
        const opacity = Math.max(0.04, (rotZ + 1.2) / 2.4 * 0.4);
        ctx.fillStyle = `rgba(0, 212, 255, ${opacity})`;
        const pSize = (rotZ + 1.5) * 1.1;
        ctx.beginPath();
        ctx.arc(x2d, y2d, pSize, 0, Math.PI * 2);
        ctx.fill();
      }

      // Glowing core
      const grad = ctx.createRadialGradient(centerX, centerY, 5, centerX, centerY, radius * 0.95);
      grad.addColorStop(0, 'rgba(0, 102, 255, 0.12)');
      grad.addColorStop(0.5, 'rgba(0, 212, 255, 0.05)');
      grad.addColorStop(1, 'rgba(5, 8, 22, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.fill();

      // Wireframe rings
      ctx.lineWidth = 0.5;
      const ringSteps = 6;
      for (let i = 0; i < ringSteps; i++) {
        const ringAngle = rotationAngle + (i * Math.PI) / ringSteps;
        ctx.strokeStyle = `rgba(0, 102, 255, ${0.03 + Math.sin(ringAngle * 2) * 0.02})`;
        ctx.beginPath();
        ctx.ellipse(centerX, centerY, radius, radius * Math.abs(Math.cos(ringAngle)), 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Orbiting service nodes
      nodes.forEach((node) => {
        const currentOrbitAngle = rotationAngle * 1.5 + node.angle;
        const orbitRx = radius * 1.45;
        const tiltX = Math.cos(currentOrbitAngle) * orbitRx;
        const tiltZ = Math.sin(currentOrbitAngle) * orbitRx;
        const cosTilt = Math.cos(Math.PI / 12);
        const sinTilt = Math.sin(Math.PI / 12);
        const finalX = centerX + tiltX * cosTilt;
        const finalY = centerY + tiltX * sinTilt + node.height * radius * 0.7;
        const depth = tiltZ;
        const nodePerspective = 2.5 / (2.5 + depth / radius);
        const size = 7 * nodePerspective;

        // Connection line
        ctx.strokeStyle = depth > 0 ? 'rgba(0, 255, 179, 0.03)' : 'rgba(0, 255, 179, 0.18)';
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(finalX, finalY);
        ctx.stroke();

        // Glow ring
        ctx.fillStyle = node.color + '1a';
        ctx.beginPath();
        ctx.arc(finalX, finalY, size * 2.8, 0, Math.PI * 2);
        ctx.fill();

        // Solid core
        ctx.fillStyle = node.color;
        ctx.beginPath();
        ctx.arc(finalX, finalY, size, 0, Math.PI * 2);
        ctx.fill();

        // Label
        if (depth > -radius * 0.5) {
          ctx.fillStyle = activeLabel === node.label ? '#FFFFFF' : '#AAB0BC';
          ctx.font = activeLabel === node.label ? '600 12px Inter' : '400 10px Inter';
          ctx.textAlign = 'center';
          ctx.fillText(node.label, finalX, finalY - size - 10);
        }
      });

      animFrame = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animFrame);
      window.removeEventListener('resize', handleResize);
    };
  }, [activeLabel]);

  return (
    <div ref={containerRef} className="absolute inset-0">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
}

export default function HeroSection() {
  const [activeLabel, setActiveLabel] = useState(null);

  const nodes = [
    { label: 'CIPC Registry', angle: 0, height: -0.4, icon: <ShieldCheck className="w-4 h-4 text-emerald-400" />, color: '#00FFB3', description: 'CIPC South Africa business registrations, startups consulting, & full legal compliance setup.' },
    { label: 'BEE Compliance', angle: (Math.PI * 2) / 6, height: 0.3, icon: <FileText className="w-4 h-4 text-cyan-400" />, color: '#00D4FF', description: 'Level 1 BEE affidavits, fast-track certifications, and compliance assistance.' },
    { label: 'Web Engine', angle: (Math.PI * 2 * 2) / 6, height: -0.1, icon: <Globe className="w-4 h-4 text-blue-500" />, color: '#0066FF', description: 'High-performance interactive web portals, school platforms, & digital storefronts.' },
    { label: 'POS & ERP Systems', angle: (Math.PI * 2 * 3) / 6, height: 0.5, icon: <Cpu className="w-4 h-4 text-emerald-400" />, color: '#00FFB3', description: 'Advanced business automation tools, point-of-sale systems, and smart inventory management.' },
    { label: 'Creative Design', angle: (Math.PI * 2 * 4) / 6, height: -0.6, icon: <Palette className="w-4 h-4 text-purple-400" />, color: '#a855f7', description: 'Corporate identity systems, logos, high-conversion vector graphics, & profiles.' },
    { label: 'Cloud Automations', angle: (Math.PI * 2 * 5) / 6, height: 0.1, icon: <Sliders className="w-4 h-4 text-cyan-400" />, color: '#00D4FF', description: 'Cloud custom systems, secure client portals, and streamlined automation tools.' },
  ];

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050816] via-transparent to-[#050816]" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-[#0066FF]/5 blur-[120px]" />
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] rounded-full bg-[#00D4FF]/3 blur-[100px]" />

      {/* Peripheral typography */}
      <div className="hidden lg:block absolute left-6 top-1/2 -translate-y-1/2 -rotate-90 origin-center">
        <span className="text-[10px] tracking-[0.4em] uppercase text-[#AAB0BC]/40 font-medium">
          EST. 2026
        </span>
      </div>
      <div className="hidden lg:block absolute right-6 top-1/2 -translate-y-1/2 rotate-90 origin-center">
        <span className="text-[10px] tracking-[0.4em] uppercase text-[#AAB0BC]/40 font-medium">
          Scroll to explore
        </span>
      </div>

      {/* Grid Core Canvas — right side only */}
      <div className="absolute right-0 top-0 w-full lg:w-[55%] h-full opacity-70 pointer-events-none">
        <GridCoreCanvas activeLabel={activeLabel} />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-24 md:pt-0 w-full">
        <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8 lg:gap-0">
          {/* Text content — left side */}
          <div className="w-full lg:w-1/2 text-center lg:text-left lg:pl-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-light mb-8"
            >
              <div className="w-2 h-2 rounded-full bg-[#00FFB3] animate-pulse" />
              <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#00D4FF]">
                Smart Digital Solutions
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.05] mb-6"
            >
              Transform Your Business Into a{" "}
              <span className="gradient-text">Digital Powerhouse</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="text-base md:text-lg text-[#AAB0BC] leading-relaxed max-w-xl mb-10"
            >
              We help entrepreneurs and companies build, automate and grow with
              professional business solutions powered by modern technology.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 }}
              className="flex flex-wrap gap-4"
            >
              <Link to="/contact">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="px-7 py-3.5 bg-[#0066FF] hover:bg-[#0055DD] rounded-xl text-sm font-semibold text-white flex items-center gap-2 glow-blue transition-all"
                >
                  Get Started
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </Link>
              <Link to="/services">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="px-7 py-3.5 glass-light rounded-xl text-sm font-semibold text-white flex items-center gap-2 hover:bg-white/10 transition-all"
                >
                  <Play className="w-4 h-4" />
                  Explore Services
                </motion.button>
              </Link>
            </motion.div>
          </div>

          {/* Spacer for globe on right */}
          <div className="hidden lg:block w-1/2" />
        </div>
      </div>

      {/* Service Grid Panel — between orbit and ticker */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 0.6 }}
        className="absolute bottom-16 left-1/2 -translate-x-1/2 z-10 w-full max-w-2xl px-6"
      >
        <div className="glass rounded-2xl p-4 border border-white/5">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00FFB3] animate-pulse" />
            <span className="text-[9px] tracking-[0.15em] font-mono text-white/60 uppercase">
              Digital Grid Core v2.6
            </span>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {nodes.map((node) => (
              <button
                key={node.label}
                onMouseEnter={() => setActiveLabel(node.label)}
                onMouseLeave={() => setActiveLabel(null)}
                onClick={() => setActiveLabel(activeLabel === node.label ? null : node.label)}
                className={`p-2 rounded-lg border transition-all text-[10px] flex flex-col items-center gap-1 cursor-pointer ${
                  activeLabel === node.label
                    ? 'bg-primary/20 border-[#00D4FF] text-white shadow-[0_0_8px_rgba(0,212,255,0.15)]'
                    : 'bg-background/30 border-white/5 text-gray-400 hover:border-blue-500/20 hover:text-white'
                }`}
              >
                {node.icon}
                <span className="text-center leading-tight">{node.label}</span>
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Trust ticker */}
      <div className="absolute bottom-0 left-0 right-0 border-t border-white/5 bg-[#050816]/80 backdrop-blur-sm">
        <div className="overflow-hidden py-4">
          <div className="animate-ticker flex whitespace-nowrap">
            {[...trustData, ...trustData].map((item, i) => (
              <div key={i} className="flex items-center gap-3 mx-8">
                <span className="text-[10px] tracking-[0.15em] uppercase text-[#AAB0BC]/60 font-mono">
                  {item.label}:
                </span>
                <span className="text-[10px] tracking-wider text-[#00FFB3] font-mono font-bold">
                  {item.value}
                </span>
                <span className="text-[#0066FF]/30">|</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}