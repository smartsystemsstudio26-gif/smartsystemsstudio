import React, { useEffect, useRef, useState } from 'react';
import { ShieldCheck, FileText, Globe, Cpu, Palette, Sliders } from 'lucide-react';

export default function DigitalGridCore() {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);
  const [activeLabel, setActiveLabel] = useState(null);
  const [activeDesc, setActiveDesc] = useState("Hover over orbiting tech hubs below to explore digital system components");

  const nodes = [
    { label: 'CIPC Registry', angle: 0, height: -0.4, icon: <ShieldCheck className="w-4 h-4 text-emerald-400" />, color: '#00FFB3', description: 'CIPC South Africa business registrations, startups consulting, & full legal compliance setup.' },
    { label: 'BEE Compliance', angle: (Math.PI * 2) / 6, height: 0.3, icon: <FileText className="w-4 h-4 text-cyan-400" />, color: '#00D4FF', description: 'Level 1 BEE affidavits, fast-track certifications, and compliance assistance.' },
    { label: 'Web Engine', angle: (Math.PI * 2 * 2) / 6, height: -0.1, icon: <Globe className="w-4 h-4 text-blue-500" />, color: '#0066FF', description: 'High-performance interactive web portals, school platforms, & digital storefronts.' },
    { label: 'POS & ERP Systems', angle: (Math.PI * 2 * 3) / 6, height: 0.5, icon: <Cpu className="w-4 h-4 text-emerald-400" />, color: '#00FFB3', description: 'Advanced business automation tools, point-of-sale systems, and smart inventory management.' },
    { label: 'Creative Design', angle: (Math.PI * 2 * 4) / 6, height: -0.6, icon: <Palette className="w-4 h-4 text-purple-400" />, color: '#a855f7', description: 'Corporate identity systems, logos, high-conversion vector graphics, & profiles.' },
    { label: 'Cloud Automations', angle: (Math.PI * 2 * 5) / 6, height: 0.1, icon: <Sliders className="w-4 h-4 text-cyan-400" />, color: '#00D4FF', description: 'Cloud custom systems, secure client portals, and streamlined automation tools.' },
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrame;
    let rotationAngle = 0;

    const handleResize = () => {
      const rect = containerRef.current?.getBoundingClientRect();
      canvas.width = rect?.width || 500;
      canvas.height = rect?.height || 500;
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    // Mathematically generate coordinates of a sphere
    const spherePoints = [];
    const bandsCount = 14;
    const pointsPerBand = 18;

    for (let i = 1; i < bandsCount; i++) {
      const theta = (i * Math.PI) / bandsCount;
      const sinTheta = Math.sin(theta);
      const cosTheta = Math.cos(theta);

      for (let j = 0; j < pointsPerBand; j++) {
        const phi = (j * 2 * Math.PI) / pointsPerBand;
        const sinPhi = Math.sin(phi);
        const cosPhi = Math.cos(phi);

        spherePoints.push({
          x: sinTheta * cosPhi,
          y: cosTheta,
          z: sinTheta * sinPhi,
        });
      }
    }

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = Math.min(canvas.width, canvas.height) * 0.32;

      rotationAngle += 0.003;

      // Draw mathematical outer halo
      ctx.strokeStyle = 'rgba(0, 212, 255, 0.04)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * 1.35, 0, Math.PI * 2);
      ctx.stroke();

      // Rotating dashed satellite track
      ctx.setLineDash([4, 12]);
      ctx.strokeStyle = 'rgba(0, 255, 179, 0.12)';
      ctx.beginPath();
      ctx.ellipse(centerX, centerY, radius * 1.5, radius * 0.35, Math.PI / 12, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw globe points with 3D projection
      for (const p of spherePoints) {
        const cosY = Math.cos(rotationAngle);
        const sinY = Math.sin(rotationAngle);

        const rotX = p.x * cosY - p.z * sinY;
        const rotZ = p.x * sinY + p.z * cosY;

        const perspective = 2.5 / (2.5 + rotZ);
        const x2d = centerX + rotX * radius * perspective;
        const y2d = centerY + p.y * radius * perspective;

        const opacity = Math.max(0.04, (rotZ + 1.2) / 2.4 * 0.4);
        ctx.fillStyle = `rgba(0, 212, 255, ${opacity})`;

        const pSize = (rotZ + 1.5) * 1.1;
        ctx.beginPath();
        ctx.arc(x2d, y2d, pSize, 0, Math.PI * 2);
        ctx.fill();
      }

      // Draw glowing Core of the globe
      const grad = ctx.createRadialGradient(centerX, centerY, 5, centerX, centerY, radius * 0.95);
      grad.addColorStop(0, 'rgba(0, 102, 255, 0.12)');
      grad.addColorStop(0.5, 'rgba(0, 212, 255, 0.05)');
      grad.addColorStop(1, 'rgba(5, 8, 22, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.fill();

      // Render latitude/longitude grid wireframes
      ctx.lineWidth = 0.5;
      const ringSteps = 6;
      for (let i = 0; i < ringSteps; i++) {
        const ringAngle = rotationAngle + (i * Math.PI) / ringSteps;
        ctx.strokeStyle = `rgba(0, 102, 255, ${0.03 + Math.sin(ringAngle * 2) * 0.02})`;
        ctx.beginPath();
        ctx.ellipse(centerX, centerY, radius, radius * Math.abs(Math.cos(ringAngle)), 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Draw floating satellite business nodes
      nodes.forEach((node) => {
        const currentOrbitAngle = rotationAngle * 1.5 + node.angle;

        const orbitRx = radius * 1.45;
        const orbitRy = radius * 0.4;
        const tiltX = Math.cos(currentOrbitAngle) * orbitRx;
        const tiltZ = Math.sin(currentOrbitAngle) * orbitRx;

        const cosTilt = Math.cos(Math.PI / 12);
        const sinTilt = Math.sin(Math.PI / 12);

        const finalX = centerX + tiltX * cosTilt;
        const finalY = centerY + tiltX * sinTilt + node.height * radius * 0.7;
        const depth = tiltZ;

        const nodePerspective = 2.5 / (2.5 + depth / radius);
        const size = 6 * nodePerspective;

        // Draw connection string to center
        ctx.strokeStyle = depth > 0 ? 'rgba(0, 255, 179, 0.03)' : 'rgba(0, 255, 179, 0.18)';
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(finalX, finalY);
        ctx.stroke();

        // Node Glow Ring
        ctx.fillStyle = node.color + '1a';
        ctx.beginPath();
        ctx.arc(finalX, finalY, size * 2.8, 0, Math.PI * 2);
        ctx.fill();

        // Inner Solid core
        ctx.fillStyle = node.color;
        ctx.beginPath();
        ctx.arc(finalX, finalY, size, 0, Math.PI * 2);
        ctx.fill();

        // Node Label if it is in front
        if (depth > -radius * 0.5) {
          ctx.fillStyle = activeLabel === node.label ? '#FFFFFF' : '#AAB0BC';
          ctx.font = activeLabel === node.label ? '600 11px Inter' : '400 9px Inter';
          ctx.textAlign = 'center';
          ctx.fillText(node.label, finalX, finalY - size - 8);
        }
      });

      animFrame = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animFrame);
      window.removeEventListener('resize', handleResize);
    };
  }, [activeLabel]);

  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-[#050816]" />
      <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] rounded-full bg-[#0066FF]/4 blur-[150px]" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-[#00FFB3]/3 blur-[100px]" />

      <div ref={containerRef} className="relative w-full h-[380px] md:h-[450px] flex flex-col justify-between items-center bg-transparent z-10 select-none max-w-5xl mx-auto px-6">
        <div className="absolute top-0 w-full h-full">
          <canvas ref={canvasRef} className="w-full h-full block" />
        </div>

        {/* Floating Status panel at the bottom of the globe widget */}
        <div className="mt-auto w-full max-w-md mx-auto p-4 rounded-xl border border-blue-500/10 bg-card/80 backdrop-blur-md shadow-2xl relative z-20 text-center transition-all duration-300 transform translate-y-3">
          <div className="absolute -top-2 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-primary text-[8px] tracking-[0.2em] font-mono text-white rounded-full uppercase border border-cyan-400/20">
            Digital Grid Core v2.6
          </div>

          {/* Orbit Grid Buttons */}
          <div className="grid grid-cols-3 gap-1.5 mb-3 mt-1">
            {nodes.map((node) => (
              <button
                key={node.label}
                onMouseEnter={() => {
                  setActiveLabel(node.label);
                  setActiveDesc(node.description);
                }}
                onMouseLeave={() => {
                  setActiveLabel(null);
                  setActiveDesc("Hover over orbiting tech hubs below to explore digital system components");
                }}
                onClick={() => {
                  setActiveLabel(node.label);
                  setActiveDesc(node.description);
                }}
                className={`p-1.5 rounded-lg border text-left transition-all text-[10px] flex items-center gap-1 cursor-pointer truncate ${
                  activeLabel === node.label
                    ? 'bg-primary/20 border-[#00D4FF] text-white shadow-[0_0_12px_rgba(0,212,255,0.2)]'
                    : 'bg-background border-white/5 text-gray-400 hover:border-blue-500/30 hover:text-white'
                }`}
              >
                {node.icon}
                <span className="truncate">{node.label}</span>
              </button>
            ))}
          </div>

          {/* Dynamic Detail Textbox */}
          <div className="h-[48px] md:h-[40px] flex items-center justify-center">
            <p className="text-xs text-slate-300 font-body leading-tight transition-all duration-200">
              {activeDesc}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}