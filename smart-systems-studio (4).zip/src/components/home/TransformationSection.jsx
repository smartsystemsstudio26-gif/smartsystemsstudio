import React, { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Play, Pause, Volume2, VolumeX } from "lucide-react";

const transformationVideo = "https://media.base44.com/videos/public/6a2c1a6b852e53957d49448d/cae45cda3_Building_transformation_animatio_202606161509.mp4";

export default function TransformationSection() {
  const videoRef = useRef(null);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);

  const togglePlay = () => {
    if (videoRef.current) {
      if (playing) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setPlaying(!playing);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !muted;
      setMuted(!muted);
    }
  };

  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] rounded-full bg-[#0066FF]/6 blur-[100px]" />
        <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] rounded-full bg-[#00FFB3]/4 blur-[80px]" />
      </div>

      <div className="max-w-6xl mx-auto px-6 relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#00FFB3]/10 mb-6">
            <Sparkles className="w-3 h-3 text-[#00FFB3]" />
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#00FFB3]">
              The Evolution
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight mb-5">
            We Drag Business Out of the{" "}
            <span className="text-[#AAB0BC]">Paper Age</span>{" "}
            Into the <span className="gradient-text">Digital Era</span>
          </h2>
          <p className="text-base md:text-lg text-[#AAB0BC] max-w-2xl mx-auto leading-relaxed">
            Paper forms. Endless queues. Lost documents. Manual ledgers. We rip all of that out and replace it with sleek digital systems, automated workflows, and cloud-based tools that run your business from your pocket. No jargon. No complexity. Just results.
          </p>
        </motion.div>

        {/* Video Player */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative rounded-2xl overflow-hidden border border-white/10 group"
        >
          <div className="relative aspect-video bg-black">
            <video
              ref={videoRef}
              src={transformationVideo}
              autoPlay
              loop
              muted={muted}
              playsInline
              className="absolute inset-0 w-full h-full object-cover"
              onEnded={() => setPlaying(false)}
            />

            {/* Overlay gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

            {/* Controls overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-6 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="flex items-center gap-3">
                <button
                  onClick={togglePlay}
                  className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center hover:bg-white/20 transition-all"
                >
                  {playing ? (
                    <Pause className="w-4 h-4 text-white" />
                  ) : (
                    <Play className="w-4 h-4 text-white ml-0.5" />
                  )}
                </button>
                <button
                  onClick={toggleMute}
                  className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center hover:bg-white/20 transition-all"
                >
                  {muted ? (
                    <VolumeX className="w-4 h-4 text-white" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-white" />
                  )}
                </button>
              </div>
              <span className="text-xs font-semibold tracking-wider text-white/70">
                THE TRANSFORMATION
              </span>
            </div>

            {/* Center play button (visible when paused) */}
            {!playing && (
              <button
                onClick={togglePlay}
                className="absolute inset-0 flex items-center justify-center bg-black/30"
              >
                <div className="w-16 h-16 rounded-full bg-[#0066FF]/80 flex items-center justify-center hover:bg-[#0066FF] transition-all glow-blue">
                  <Play className="w-6 h-6 text-white ml-1" />
                </div>
              </button>
            )}
          </div>
        </motion.div>

        {/* Timeline labels */}
        <div className="flex justify-center gap-6 mt-6">
          <span className="px-5 py-2 rounded-xl text-sm font-medium bg-white/5 text-[#AAB0BC]">
            2024 — The Beginning
          </span>
          <span className="text-[#AAB0BC]/40 self-center text-2xl">→</span>
          <span className="px-5 py-2 rounded-xl text-sm font-medium bg-[#00FFB3]/10 text-[#00FFB3]">
            Today — The Future
          </span>
        </div>
      </div>
    </section>
  );
}