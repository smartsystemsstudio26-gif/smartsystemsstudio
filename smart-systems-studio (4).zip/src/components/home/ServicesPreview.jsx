import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Building2,
  Award,
  Globe,
  Monitor,
  Palette,
  Cloud,
  ArrowRight,
} from "lucide-react";
import SectionHeading from "../shared/SectionHeading";
import GlassCard from "../shared/GlassCard";

const services = [
  { icon: Building2, title: "Business & CIPC Registration", price: "R499", desc: "Fast company registration, direct CIPC compliance filings, SARS tax setups, and startup consulting.", color: "#0066FF" },
  { icon: Award, title: "BEE Certificates", price: "R349", desc: "BEE affidavits, certificates and full compliance assistance for your business.", color: "#00D4FF" },
  { icon: Globe, title: "Websites & Management Systems", price: "R1,999", desc: "Stunning custom websites, featuring specialized School and Church websites with premium responsive designs.", color: "#00FFB3" },
  { icon: Monitor, title: "School, Church & Business Software", price: "R3,499", desc: "Bespoke School and Church management software systems, modern POS, inventory, CRM, and cloud integrations.", color: "#0066FF" },
  { icon: Palette, title: "Graphic Design", price: "R199", desc: "Logos, flyers, posters, social media graphics and company profiles.", color: "#00D4FF" },
  { icon: Cloud, title: "Digital Solutions", price: "R899", desc: "Online forms, automation tools, cloud solutions and custom systems.", color: "#00FFB3" },
];

export default function ServicesPreview() {
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute top-1/2 left-0 w-[500px] h-[500px] rounded-full bg-[#0066FF]/3 blur-[150px] -translate-y-1/2" />
      <div className="max-w-7xl mx-auto px-6 relative">
        <SectionHeading
          badge="Our Services"
          title="End-to-End Business Solutions"
          description="From registration to digital transformation — everything your business needs to launch, grow and scale."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <GlassCard key={i} delay={i * 0.1} glowColor={`${service.color}20`}>
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-5"
                style={{ background: `${service.color}15` }}
              >
                <service.icon className="w-6 h-6" style={{ color: service.color }} />
              </div>
              <div className="flex flex-col mb-3">
                <h3 className="text-lg font-bold text-white mb-1.5">{service.title}</h3>
                <div className="flex items-center gap-1.5 py-0.5 px-2 rounded bg-white/[0.03] border border-white/5 w-fit">
                  <span className="text-[10px] text-[#AAB0BC] tracking-wider uppercase font-medium">Starting from</span>
                  <span className="text-xs font-bold" style={{ color: service.color }}>{service.price}</span>
                </div>
              </div>
              <p className="text-sm text-[#AAB0BC] leading-relaxed mb-5">{service.desc}</p>
              <Link
                to="/services"
                className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase group"
                style={{ color: service.color }}
              >
                Learn More
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </Link>
            </GlassCard>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Link to="/services">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="px-7 py-3.5 glass-light rounded-xl text-sm font-semibold text-white hover:bg-white/10 transition-all inline-flex items-center gap-2"
            >
              View All Services
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}