import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Zap } from "lucide-react";
import GlassCard from "../shared/GlassCard";

export default function CTASection() {
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[#0066FF]/8 blur-[120px]" />
      </div>
      <div className="max-w-4xl mx-auto px-6 relative">
        <GlassCard glowColor="rgba(0,102,255,0.12)" className="w-full">
          <div className="p-4 md:p-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#00FFB3]/10 mb-6">
              <Zap className="w-3 h-3 text-[#00FFB3]" />
              <span className="text-xs font-semibold tracking-wider uppercase text-[#00FFB3]">
                Ready to Transform?
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white mb-5 leading-tight">
              Let's Build Something{" "}
              <span className="gradient-text">Extraordinary</span>
            </h2>
            <p className="text-base text-[#AAB0BC] max-w-xl mx-auto mb-10 leading-relaxed">
              Whether you're starting a new business or scaling an existing one, we have
              the solutions to take you to the next level.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/contact">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="px-8 py-4 bg-[#0066FF] hover:bg-[#0055DD] rounded-xl text-sm font-semibold text-white inline-flex items-center gap-2 glow-blue transition-all"
                >
                  Start Your Project
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </Link>
              <a href="tel:+27630751348">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="px-8 py-4 glass-light rounded-xl text-sm font-semibold text-white hover:bg-white/10 transition-all"
                >
                  Call Us Now
                </motion.button>
              </a>
            </div>
          </div>
        </GlassCard>
      </div>
    </section>
  );
}