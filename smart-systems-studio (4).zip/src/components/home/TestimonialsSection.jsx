import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import SectionHeading from "../shared/SectionHeading";

const testimonials = [
  {
    name: "Thabo Molefe",
    role: "CEO, TechVentures SA",
    rating: 5,
    text: "Smart Systems Studio transformed our entire business operations. Their POS system and website have increased our revenue by 40%. Absolutely world-class service.",
  },
  {
    name: "Naledi Dlamini",
    role: "Founder, Creative Bloom",
    rating: 5,
    text: "The branding and website they created for us is stunning. Our clients constantly compliment our professional online presence. Best investment we've made.",
  },
  {
    name: "James van der Merwe",
    role: "Director, Urban Properties",
    rating: 5,
    text: "From company registration to a fully automated CRM system — they handled everything. Professional, fast and incredibly affordable. Highly recommended.",
  },
  {
    name: "Sipho Nkosi",
    role: "Owner, Nkosi Fresh Market",
    rating: 5,
    text: "Their inventory management system saved us thousands. We can now track everything in real-time. The ongoing support has been exceptional.",
  },
  {
    name: "Fatima Patel",
    role: "Principal, Sunrise Academy",
    rating: 5,
    text: "Our school website is beautiful and functional. Parents love the new online registration system. Smart Systems Studio truly understands education.",
  },
];

export default function TestimonialsSection() {
  const [current, setCurrent] = useState(0);
  const cardRef = useRef(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glowX, setGlowX] = useState(50);
  const [glowY, setGlowY] = useState(50);

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    setRotateX(((y - centerY) / centerY) * -10);
    setRotateY(((x - centerX) / centerX) * 10);
    setGlowX((x / rect.width) * 100);
    setGlowY((y / rect.height) * 100);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setGlowX(50);
    setGlowY(50);
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const prev = () => setCurrent((c) => (c - 1 + testimonials.length) % testimonials.length);
  const next = () => setCurrent((c) => (c + 1) % testimonials.length);

  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0066FF]/3 to-transparent" />
      <div className="max-w-4xl mx-auto px-6 relative">
        <SectionHeading
          badge="Testimonials"
          title="What Our Clients Say"
          description="Real results from real businesses. See how we're making a difference."
        />

        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, x: 50, scale: 0.96 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -50, scale: 0.96 }}
              transition={{ duration: 0.4 }}
              className="group perspective-[1000px] hover:z-20 w-full"
            >
              <motion.div
                animate={{
                  y: [0, -6, 0],
                }}
                transition={{
                  y: {
                    repeat: Infinity,
                    duration: 4.5,
                    ease: "easeInOut",
                  }
                }}
                whileHover={{
                  y: -14,
                  scale: 1.03,
                  transition: { duration: 0.3, ease: "easeOut" }
                }}
                className="w-full relative"
              >
                <div
                  ref={cardRef}
                  onMouseMove={handleMouseMove}
                  onMouseLeave={handleMouseLeave}
                  className="glass rounded-2xl p-8 md:p-12 text-center relative overflow-hidden transition-all duration-200 ease-out hover:shadow-[0_20px_45px_rgba(0,102,255,0.22)] border border-white/10 hover:border-[#00D4FF]/30 cursor-pointer"
                  style={{
                    transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
                    transformStyle: "preserve-3d",
                  }}
                >
                  {/* Moving glow overlay */}
                  <div
                    className="absolute inset-0 pointer-events-none transition-opacity duration-300 opacity-0 group-hover:opacity-100 rounded-2xl"
                    style={{
                      background: `radial-gradient(circle at ${glowX}% ${glowY}%, rgba(0,212,255,0.12) 0%, transparent 60%)`,
                    }}
                  />

                  <div className="relative z-10 flex-1 flex flex-col" style={{ transform: "translateZ(25px)", transformStyle: "preserve-3d" }}>
                    <Quote className="w-10 h-10 text-[#0066FF]/30 mx-auto mb-6" />
                    <p className="text-base md:text-lg text-white/90 leading-relaxed mb-8 max-w-2xl mx-auto">
                      "{testimonials[current].text}"
                    </p>
                    <div className="flex justify-center gap-1 mb-4">
                      {Array.from({ length: testimonials[current].rating }).map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-[#00FFB3] text-[#00FFB3]" />
                      ))}
                    </div>
                    <p className="font-bold text-white">{testimonials[current].name}</p>
                    <p className="text-sm text-[#AAB0BC]">{testimonials[current].role}</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-center items-center gap-4 mt-8">
            <button
              onClick={prev}
              className="p-2 rounded-full glass-light hover:bg-white/10 transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-5 h-5 text-white" />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    i === current ? "bg-[#0066FF] w-6" : "bg-white/20"
                  }`}
                  aria-label={`Go to testimonial ${i + 1}`}
                />
              ))}
            </div>
            <button
              onClick={next}
              className="p-2 rounded-full glass-light hover:bg-white/10 transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}