import React from "react";
import AnimatedCounter from "../shared/AnimatedCounter";
import GlassCard from "../shared/GlassCard";

const stats = [
  { target: 280, suffix: "+", label: "Businesses Supported" },
  { target: 452, suffix: "+", label: "Websites Built" },
  { target: 650, suffix: "+", label: "Projects Completed" },
  { target: 98, suffix: "%", label: "Client Satisfaction" },
];

export default function StatsSection() {
  return (
    <section className="relative py-12">
      <div className="absolute inset-0 bg-gradient-to-r from-[#0066FF]/5 via-transparent to-[#00D4FF]/5 pointer-events-none" />
      <div className="relative max-w-6xl mx-auto px-6">
        <GlassCard glowColor="rgba(0,102,255,0.1)" className="w-full">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 py-4 px-2">
            {stats.map((stat, i) => (
              <AnimatedCounter
                key={i}
                target={stat.target}
                suffix={stat.suffix}
                label={stat.label}
              />
            ))}
          </div>
        </GlassCard>
      </div>
    </section>
  );
}