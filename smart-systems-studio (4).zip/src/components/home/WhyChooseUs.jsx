import React, { useState, useRef } from "react";
import { motion } from "framer-motion";
import {
  Shield,
  Zap,
  Clock,
  HeadphonesIcon,
  Cpu,
  Heart,
} from "lucide-react";
import SectionHeading from "../shared/SectionHeading";

const reasons = [
  { icon: Shield, title: "Professional Solutions", desc: "Enterprise-grade quality for businesses of all sizes.", color: "#0066FF" },
  { icon: Zap, title: "Affordable Pricing", desc: "Premium solutions that respect your budget.", color: "#00D4FF" },
  { icon: Clock, title: "Fast Delivery", desc: "Rapid turnaround without compromising quality.", color: "#00FFB3" },
  { icon: HeadphonesIcon, title: "Ongoing Support", desc: "Dedicated support long after project completion.", color: "#0066FF" },
  { icon: Cpu, title: "Modern Technology", desc: "Cutting-edge tools and platforms for future-proof results.", color: "#00D4FF" },
  { icon: Heart, title: "Customer Satisfaction", desc: "Your success is our ultimate measure of achievement.", color: "#00FFB3" },
];

function ReasonCard({ r, index }) {
  const cardRef = useRef(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glowX, setGlowX] = useState(50);
  const [glowY, setGlowY] = useState(50);

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    setRotateX(((y - centerY) / centerY) * -10);
    setRotateY(((x - centerX) / centerX) * 10);
    setGlowX((x / rect.width) * 100);
    setGlowY((y / rect.height) * 100);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setGlowX(50);
    setGlowY(50);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group perspective-[1000px] hover:z-20"
    >
      <motion.div
        animate={{
          y: [0, -6, 0],
        }}
        transition={{
          y: {
            repeat: Infinity,
            duration: 4.5,
            ease: "easeInOut",
            delay: index * 0.15,
          }
        }}
        whileHover={{
          y: -14,
          scale: 1.04,
          transition: { duration: 0.3, ease: "easeOut" }
        }}
        className="w-full h-full relative"
      >
        <div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="glass rounded-2xl p-6 relative overflow-hidden transition-all duration-200 ease-out hover:shadow-[0_20px_45px_rgba(0,102,255,0.22)] border-white/10 hover:border-[#00D4FF]/30 h-full flex flex-col"
          style={{
            transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
            transformStyle: "preserve-3d",
          }}
        >
          {/* Moving glow overlay */}
          <div
            className="absolute inset-0 pointer-events-none transition-opacity duration-300 opacity-0 group-hover:opacity-100 rounded-2xl"
            style={{
              background: `radial-gradient(circle at ${glowX}% ${glowY}%, ${r.color}15 0%, transparent 60%)`,
            }}
          />

          <div className="relative z-10 flex-1 flex flex-col" style={{ transform: "translateZ(25px)", transformStyle: "preserve-3d" }}>
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110"
              style={{ background: `${r.color}12` }}
            >
              <r.icon className="w-5 h-5" style={{ color: r.color }} />
            </div>
            <h3 className="text-base font-bold text-white mb-2">{r.title}</h3>
            <p className="text-sm text-[#AAB0BC] leading-relaxed">{r.desc}</p>
          </div>

          <div
            className="absolute bottom-0 left-0 w-0 h-[2px] group-hover:w-full transition-all duration-500 rounded-b-2xl"
            style={{ background: r.color }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function WhyChooseUs() {
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute top-0 right-0 w-[600px] h-[600px] rounded-full bg-[#00FFB3]/3 blur-[150px]" />
      <div className="max-w-7xl mx-auto px-6 relative">
        <SectionHeading
          badge="Why Choose Us"
          title="The Smart Systems Advantage"
          description="We combine innovation, expertise and dedication to deliver results that exceed expectations."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((r, i) => (
            <ReasonCard key={i} r={r} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}