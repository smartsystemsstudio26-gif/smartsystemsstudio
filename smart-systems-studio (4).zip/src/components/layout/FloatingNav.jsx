import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Home, Briefcase, FolderOpen, Phone, Info, Menu, X } from "lucide-react";

const navItems = [
  { path: "/", label: "Home", icon: Home },
  { path: "/services", label: "Services", icon: Briefcase },
  { path: "/portfolio", label: "Portfolio", icon: FolderOpen },
  { path: "/about", label: "About", icon: Info },
  { path: "/contact", label: "Contact", icon: Phone },
];

export default function FloatingNav() {
  const location = useLocation();
  const [expanded, setExpanded] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setExpanded(false);
  }, [location.pathname]);

  return (
    <>
      {/* Desktop floating dock */}
      <motion.nav
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, type: "spring", stiffness: 100 }}
        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 hidden md:flex"
      >
        <div className="glass rounded-2xl px-2 py-2 flex items-center gap-1">
          <Link to="/" className="flex items-center gap-2 px-3 py-2 mr-2">
            <img src="https://media.base44.com/images/public/6a2c1a6b852e53957d49448d/1b250977f_ChatGPTImageJun12202604_15_28PM.png" alt="Smart Systems Studio" className="w-auto object-contain" style={{ height: "112px" }} />
          </Link>
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link key={item.path} to={item.path}>
                <motion.div
                  whileHover={{ scale: 1.1, y: -4 }}
                  whileTap={{ scale: 0.95 }}
                  className={`relative flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                    isActive
                      ? "bg-[#0066FF]/20 text-white"
                      : "text-[#AAB0BC] hover:text-white hover:bg-white/5"
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {isActive && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute inset-0 rounded-xl bg-[#0066FF]/15 border border-[#0066FF]/30"
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}
                </motion.div>
              </Link>
            );
          })}
        </div>
      </motion.nav>

      {/* Mobile nav */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50">
        <motion.div
          initial={{ y: -100 }}
          animate={{ y: 0 }}
          className={`flex items-center justify-between px-5 py-4 transition-all duration-500 ${
            scrolled ? "glass" : "bg-transparent"
          }`}
        >
          <Link to="/" className="flex items-center gap-2">
            <img src="https://media.base44.com/images/public/6a2c1a6b852e53957d49448d/1b250977f_ChatGPTImageJun12202604_15_28PM.png" alt="Smart Systems Studio" className="w-auto object-contain" style={{ height: "88px" }} />
          </Link>
          <button
            onClick={() => setExpanded(!expanded)}
            className="p-2 rounded-lg glass-light"
          >
            {expanded ? <X className="w-5 h-5 text-white" /> : <Menu className="w-5 h-5 text-white" />}
          </button>
        </motion.div>

        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="glass mx-4 rounded-2xl overflow-hidden"
            >
              <div className="py-4 px-2 flex flex-col gap-1">
                {navItems.map((item) => {
                  const isActive = location.pathname === item.path;
                  return (
                    <Link key={item.path} to={item.path}>
                      <div
                        className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                          isActive
                            ? "bg-[#0066FF]/20 text-white"
                            : "text-[#AAB0BC] hover:text-white hover:bg-white/5"
                        }`}
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}