import React from "react";
import { Outlet } from "react-router-dom";
import FloatingNav from "./FloatingNav";
import Footer from "./Footer";
import WhatsAppButton from "../shared/WhatsAppButton";

export default function Layout() {
  return (
    <div className="min-h-screen bg-[#050816] text-white relative">
      <FloatingNav />
      <main>
        <Outlet />
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}