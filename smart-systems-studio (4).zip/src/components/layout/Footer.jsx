import React from "react";
import { Link } from "react-router-dom";
import { Mail, Phone, MapPin, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const quickLinks = [
  { label: "Home", path: "/" },
  { label: "Services", path: "/services" },
  { label: "Portfolio", path: "/portfolio" },
  { label: "About Us", path: "/about" },
  { label: "Contact", path: "/contact" },
];

const services = [
  "Business & CIPC Registration",
  "BEE Certificates",
  "Websites & Systems Development",
  "School, Church & Business Software",
  "Graphic Design",
  "Digital Solutions",
];

export default function Footer() {
  return (
    <footer className="relative border-t border-[#0066FF]/10">
      <div className="absolute inset-0 bg-gradient-to-t from-[#050816] via-[#0B1221] to-transparent" />
      <div className="relative max-w-7xl mx-auto px-6 pt-20 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div>
            <div className="mb-5">
              <img src="https://media.base44.com/images/public/6a2c1a6b852e53957d49448d/1b250977f_ChatGPTImageJun12202604_15_28PM.png" alt="Smart Systems Studio" className="w-auto object-contain" style={{ height: "112px" }} />
            </div>
            <p className="text-sm text-[#AAB0BC] leading-relaxed mb-6">
              Smart Digital Solutions for Modern Businesses. Building smarter businesses through technology.
            </p>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-[#00FFB3] animate-pulse" />
              <span className="text-xs text-[#00FFB3] font-medium tracking-wider uppercase">
                Systems Online
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-bold tracking-widest uppercase text-white mb-6">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-[#AAB0BC] hover:text-[#00D4FF] transition-colors flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 opacity-0 -ml-5 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-sm font-bold tracking-widest uppercase text-white mb-6">
              Services
            </h4>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service}>
                  <Link
                    to="/services"
                    className="text-sm text-[#AAB0BC] hover:text-[#00D4FF] transition-colors"
                  >
                    {service}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-bold tracking-widest uppercase text-white mb-6">
              Contact
            </h4>
            <div className="space-y-4">
              <a
                href="tel:+27630751348"
                className="flex items-center gap-3 text-sm text-[#AAB0BC] hover:text-[#00D4FF] transition-colors"
              >
                <Phone className="w-4 h-4 text-[#0066FF]" />
                +27 63 075 1348
              </a>
              <a
                href="mailto:smartsystemsstudio26@gmail.com"
                className="flex items-center gap-3 text-sm text-[#AAB0BC] hover:text-[#00D4FF] transition-colors"
              >
                <Mail className="w-4 h-4 text-[#0066FF]" />
                smartsystemsstudio26@gmail.com
              </a>
              <div className="flex items-center gap-3 text-sm text-[#AAB0BC]">
                <MapPin className="w-4 h-4 text-[#0066FF]" />
                South Africa
              </div>
            </div>

            {/* Newsletter */}
            <div className="mt-8">
              <p className="text-xs text-[#AAB0BC] mb-3">Subscribe to updates</p>
              <div className="flex gap-2">
                <input
                  type="email"
                  placeholder="Enter email"
                  className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder:text-[#AAB0BC] focus:outline-none focus:border-[#0066FF]/50"
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-3 py-2 bg-[#0066FF] rounded-lg text-xs font-medium text-white"
                >
                  <ArrowRight className="w-3 h-3" />
                </motion.button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-[#AAB0BC]">
            © 2026 Smart Systems Studio. All Rights Reserved.
          </p>
          <div className="flex items-center gap-6">
            <span className="text-xs text-[#AAB0BC]">Privacy Policy</span>
            <span className="text-xs text-[#AAB0BC]">Terms of Service</span>
          </div>
        </div>
      </div>
    </footer>
  );
}