import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  MessageCircle,
  ArrowRight,
  CheckCircle2,
  Loader2,
  Check,
} from "lucide-react";
import SectionHeading from "../components/shared/SectionHeading";
import { base44 } from "@/api/base44Client";
import GlassCard from "../components/shared/GlassCard";

const contactInfo = [
  { icon: Phone, label: "Phone", value: "+27 63 075 1348", href: "tel:+27630751348", color: "#0066FF" },
  { icon: Mail, label: "Email", value: "smartsystemsstudio26@gmail.com", href: "mailto:smartsystemsstudio26@gmail.com", color: "#00D4FF" },
  { icon: MapPin, label: "Location", value: "South Africa", href: null, color: "#00FFB3" },
  { icon: Clock, label: "Hours", value: "Mon - Fri, 8AM - 6PM", href: null, color: "#0066FF" },
];

const serviceOptions = [
  "Business & CIPC Registration",
  "BEE Certificates",
  "Websites & Systems Development (Churches, Schools, Corporate)",
  "School, Church & Business Software (Management systems, POS, CRM)",
  "Graphic Design",
  "Digital Solutions",
  "Other",
];

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    business: "",
    email: "",
    phone: "",
    service: [],
    message: "",
  });
  const [step, setStep] = useState(1);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleToggleService = (s) => {
    setForm((prev) => {
      const current = Array.isArray(prev.service) ? prev.service : [];
      const updated = current.includes(s)
        ? current.filter((item) => item !== s)
        : [...current, s];
      return { ...prev, service: updated };
    });
  };

  const handleSubmit = async () => {
    setSending(true);
    const serviceListStr = Array.isArray(form.service) ? form.service.join(", ") : form.service;
    try {
      await base44.integrations.Core.SendEmail({
        to: "smartsystemsstudio26@gmail.com",
        subject: `New Inquiry: ${serviceListStr || "Multiple Services"} — ${form.name}`,
        body: `
Name: ${form.name}
Business: ${form.business}
Email: ${form.email}
Phone: ${form.phone}
Services: ${serviceListStr}

Message:
${form.message}
        `.trim(),
      });
      setSent(true);
    } catch (e) {
      setSent(true);
    } finally {
      setSending(false);
    }
  };

  const canProceedStep1 = Array.isArray(form.service) ? form.service.length > 0 : form.service;
  const canProceedStep2 = form.name && form.email;

  return (
    <div className="min-h-screen pt-24 md:pt-16 pb-32">
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[400px] rounded-full bg-[#0066FF]/5 blur-[120px]" />
        <div className="relative max-w-7xl mx-auto px-6">
          <SectionHeading
            badge="Contact Us"
            title="Let's Start Building Together"
            description="Whether you have a question or are ready to start a project — we'd love to hear from you."
          />
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-6">
            {contactInfo.map((info, i) => (
              <GlassCard
                key={i}
                delay={i * 0.08}
                glowColor={`${info.color}18`}
                className="w-full"
              >
                <div className="flex items-start gap-4">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${info.color}12` }}
                  >
                    <info.icon className="w-5 h-5" style={{ color: info.color }} />
                  </div>
                  <div>
                    <p className="text-xs text-[#AAB0BC] tracking-wider uppercase font-medium mb-1">
                      {info.label}
                    </p>
                    {info.href ? (
                      <a
                        href={info.href}
                        className="text-sm font-semibold text-white hover:text-[#00D4FF] transition-colors break-all"
                      >
                        {info.value}
                      </a>
                    ) : (
                      <p className="text-sm font-semibold text-white">{info.value}</p>
                    )}
                  </div>
                </div>
              </GlassCard>
            ))}

            {/* Quick actions */}
            <div className="flex flex-col gap-3">
              <a href="https://wa.me/27630751348" target="_blank" rel="noopener noreferrer">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-3.5 rounded-xl bg-[#25D366] text-sm font-semibold text-white flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  Chat on WhatsApp
                </motion.button>
              </a>
              <a href="tel:+27630751348">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-3.5 rounded-xl glass-light text-sm font-semibold text-white flex items-center justify-center gap-2 hover:bg-white/10 transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  Call Us Now
                </motion.button>
              </a>
            </div>
          </div>

          {/* Smart Form */}
          <div className="lg:col-span-3">
            <GlassCard noPadding={true} className="w-full" delay={0.1} glowColor="rgba(0,102,255,0.1)">
              {/* Progress */}
              <div className="flex border-b border-white/5">
                {[1, 2, 3].map((s) => (
                  <div
                    key={s}
                    className={`flex-1 py-3 text-center text-xs font-semibold tracking-wider uppercase transition-all ${
                      step === s
                        ? "bg-[#0066FF]/10 text-[#0066FF]"
                        : step > s
                        ? "bg-[#00FFB3]/5 text-[#00FFB3]"
                        : "text-[#AAB0BC]/50"
                    }`}
                  >
                    {s === 1 ? "Service" : s === 2 ? "Details" : "Message"}
                  </div>
                ))}
              </div>

              <div className="p-7 md:p-9">
                {sent ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12"
                  >
                    <div className="w-16 h-16 rounded-full bg-[#00FFB3]/10 flex items-center justify-center mx-auto mb-5">
                      <CheckCircle2 className="w-8 h-8 text-[#00FFB3]" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Message Sent!</h3>
                    <p className="text-sm text-[#AAB0BC]">
                      We'll get back to you within 24 hours. Thank you!
                    </p>
                  </motion.div>
                ) : (
                  <>
                    {/* Step 1: Select Service */}
                    {step === 1 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="space-y-4"
                      >
                        <h3 className="text-lg font-bold text-white mb-1">
                          What are we building today?
                        </h3>
                        <p className="text-sm text-[#AAB0BC] mb-5">Select the services you're interested in (you can select more than one).</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {serviceOptions.map((s) => {
                            const isSelected = Array.isArray(form.service) ? form.service.includes(s) : form.service === s;
                            return (
                              <button
                                key={s}
                                type="button"
                                onClick={() => handleToggleService(s)}
                                className={`p-4 rounded-xl text-left text-sm font-medium transition-all flex justify-between items-center group ${
                                  isSelected
                                    ? "bg-[#0066FF]/15 text-white border border-[#0066FF]/35"
                                    : "bg-white/3 text-[#AAB0BC] border border-white/5 hover:border-white/15 hover:text-white"
                                }`}
                              >
                                <span>{s}</span>
                                <div
                                  className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                                    isSelected
                                      ? "bg-[#00D4FF] border-[#00D4FF] text-[#050816]"
                                      : "border-white/10 group-hover:border-white/20"
                                  }`}
                                >
                                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                        <div className="flex justify-end pt-4">
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => canProceedStep1 && setStep(2)}
                            disabled={!canProceedStep1}
                            className={`px-6 py-3 rounded-xl text-sm font-semibold flex items-center gap-2 ${
                              canProceedStep1
                                ? "bg-[#0066FF] text-white"
                                : "bg-white/5 text-[#AAB0BC] cursor-not-allowed"
                            }`}
                          >
                            Continue <ArrowRight className="w-4 h-4" />
                          </motion.button>
                        </div>
                      </motion.div>
                    )}

                    {/* Step 2: Your details */}
                    {step === 2 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="space-y-4"
                      >
                        <h3 className="text-lg font-bold text-white mb-1">Tell us about you</h3>
                        <p className="text-sm text-[#AAB0BC] mb-5">So we can reach you.</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <input
                            type="text"
                            placeholder="Your Name *"
                            value={form.name}
                            onChange={(e) => handleChange("name", e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-[#AAB0BC]/60 focus:outline-none focus:border-[#0066FF]/50"
                          />
                          <input
                            type="text"
                            placeholder="Business Name"
                            value={form.business}
                            onChange={(e) => handleChange("business", e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-[#AAB0BC]/60 focus:outline-none focus:border-[#0066FF]/50"
                          />
                          <input
                            type="email"
                            placeholder="Email Address *"
                            value={form.email}
                            onChange={(e) => handleChange("email", e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-[#AAB0BC]/60 focus:outline-none focus:border-[#0066FF]/50"
                          />
                          <input
                            type="tel"
                            placeholder="Phone Number"
                            value={form.phone}
                            onChange={(e) => handleChange("phone", e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-[#AAB0BC]/60 focus:outline-none focus:border-[#0066FF]/50"
                          />
                        </div>
                        <div className="flex justify-between pt-4">
                          <button
                            onClick={() => setStep(1)}
                            className="px-5 py-3 rounded-xl text-sm font-medium text-[#AAB0BC] hover:text-white transition-colors"
                          >
                            Back
                          </button>
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => canProceedStep2 && setStep(3)}
                            disabled={!canProceedStep2}
                            className={`px-6 py-3 rounded-xl text-sm font-semibold flex items-center gap-2 ${
                              canProceedStep2
                                ? "bg-[#0066FF] text-white"
                                : "bg-white/5 text-[#AAB0BC] cursor-not-allowed"
                            }`}
                          >
                            Continue <ArrowRight className="w-4 h-4" />
                          </motion.button>
                        </div>
                      </motion.div>
                    )}

                    {/* Step 3: Message */}
                    {step === 3 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="space-y-4"
                      >
                        <h3 className="text-lg font-bold text-white mb-1">Describe your project</h3>
                        <p className="text-sm text-[#AAB0BC] mb-5">The more detail, the better we can help.</p>
                        <textarea
                          placeholder="Tell us about your project, goals and timeline..."
                          value={form.message}
                          onChange={(e) => handleChange("message", e.target.value)}
                          rows={6}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-[#AAB0BC]/60 focus:outline-none focus:border-[#0066FF]/50 resize-none"
                        />
                        <div className="flex justify-between pt-4">
                          <button
                            onClick={() => setStep(2)}
                            className="px-5 py-3 rounded-xl text-sm font-medium text-[#AAB0BC] hover:text-white transition-colors"
                          >
                            Back
                          </button>
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleSubmit}
                            disabled={sending}
                            className="px-6 py-3 rounded-xl bg-[#00FFB3] text-[#050816] text-sm font-bold flex items-center gap-2 glow-green"
                          >
                            {sending ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin" />
                                Sending...
                              </>
                            ) : (
                              <>
                                <Send className="w-4 h-4" />
                                Deploy Message
                              </>
                            )}
                          </motion.button>
                        </div>
                      </motion.div>
                    )}
                  </>
                )}
              </div>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="max-w-7xl mx-auto px-6 mt-16">
        <GlassCard noPadding={true} className="w-full" delay={0.15} glowColor="rgba(0,212,255,0.08)">
          <div className="p-1 overflow-hidden w-full h-full">
            <div className="h-64 md:h-80 rounded-2xl bg-gradient-to-br from-[#0066FF]/5 via-[#0B1221] to-[#00D4FF]/5 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-8 h-8 text-[#0066FF]/40 mx-auto mb-3" />
                <p className="text-sm text-[#AAB0BC]">South Africa</p>
                <p className="text-xs text-[#AAB0BC]/60 mt-1">Serving businesses nationwide</p>
              </div>
            </div>
          </div>
        </GlassCard>
      </section>
    </div>
  );
}