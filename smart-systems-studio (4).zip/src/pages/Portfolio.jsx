import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import PortfolioGallery from "../components/portfolio/PortfolioGallery";

export default function Portfolio() {
  return (
    <div className="min-h-screen pt-24 md:pt-16 pb-32">
      <PortfolioGallery />

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-6 mt-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass rounded-3xl p-10 md:p-14 text-center"
        >
          <h3 className="text-2xl md:text-3xl font-extrabold text-white mb-4">
            Want Results Like These?
          </h3>
          <p className="text-[#AAB0BC] mb-8 max-w-lg mx-auto">
            Let's create something extraordinary for your business. Your project could be next.
          </p>
          <Link to="/contact">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="px-8 py-4 bg-[#0066FF] rounded-xl text-sm font-semibold text-white inline-flex items-center gap-2 glow-blue"
            >
              Start Your Project
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </Link>
        </motion.div>
      </section>
    </div>
  );
}