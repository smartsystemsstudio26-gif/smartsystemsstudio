import React, { useState, useRef } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Building2,
  Award,
  Globe,
  Monitor,
  Palette,
  Cloud,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import SectionHeading from "../components/shared/SectionHeading";
import ServiceEstimator from "../components/estimator/ServiceEstimator";

const services = [
  {
    icon: Building2,
    title: "Business & CIPC Registration",
    desc: "Launch your business with confidence. We handle official CIPC company filings, tax setup, compliance and startup consulting.",
    color: "#0066FF",
    price: "R499",
    features: ["Direct CIPC Registration", "CIPC Compliance Filing", "Tax & VAT Registration Assistance", "Initial Startup Business Profiles"],
  },
  {
    icon: Award,
    title: "BEE Certificates",
    desc: "Ensure your business meets all BEE requirements with our comprehensive compliance solutions.",
    color: "#00D4FF",
    price: "R349",
    features: ["BEE Affidavits", "BEE Certificates", "Compliance Assistance"],
  },
  {
    icon: Globe,
    title: "Websites & Management Systems",
    desc: "Beautiful, fast, responsive websites, specializing in high-performance Church and School web systems.",
    color: "#00FFB3",
    price: "R1,999",
    features: ["Specialized Church & School Websites", "Corporate Web Applications", "Secure E-Commerce Portals", "Responsive Layout Masterclass"],
  },
  {
    icon: Monitor,
    title: "School, Church & Business Software",
    desc: "Custom software applications configured to streamline administrative overhead, with premium cloud databases.",
    color: "#0066FF",
    price: "R3,499",
    features: ["Church & School Management Systems", "Advanced Point of Sale (POS)", "Smart Inventory Tracking", "Integrated CRM Databases", "Administration Automation Tools"],
  },
  {
    icon: Palette,
    title: "Graphic Design",
    desc: "Stunning visual identities that make your brand unforgettable and build lasting impressions.",
    color: "#00D4FF",
    price: "R199",
    features: ["Business Logos", "Flyers", "Posters", "Social Media Graphics", "Company Profiles"],
  },
  {
    icon: Cloud,
    title: "Digital Solutions",
    desc: "Modern cloud-based tools and automation systems to streamline your business processes.",
    color: "#00FFB3",
    price: "R899",
    features: ["Online Forms", "Automation Tools", "Cloud Solutions", "Custom Systems"],
  },
];

function ServiceCard({ service, index }) {
  const [expanded, setExpanded] = useState(false);
  const cardRef = useRef(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glowX, setGlowX] = useState(50);
  const [glowY, setGlowY] = useState(50);

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    setRotateX(((y - centerY) / centerY) * -10); // enhanced 3D tilt
    setRotateY(((x - centerX) / centerX) * 10);
    setGlowX((x / rect.width) * 100);
    setGlowY((y / rect.height) * 100);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setGlowX(50);
    setGlowY(50);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group perspective-[1000px] hover:z-20"
    >
      <motion.div
        animate={{
          y: [0, -6, 0],
        }}
        transition={{
          y: {
            repeat: Infinity,
            duration: 4.5,
            ease: "easeInOut",
            delay: index * 0.15,
          }
        }}
        whileHover={{
          y: -14,
          scale: 1.04,
          transition: { duration: 0.3, ease: "easeOut" }
        }}
        className="w-full h-full relative"
      >
        <div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="glass rounded-2xl overflow-hidden animate-border-glow h-full flex flex-col transition-all duration-200 ease-out relative hover:shadow-[0_20px_45px_rgba(0,102,255,0.22)] border-white/10 hover:border-[#00D4FF]/30"
          style={{
            transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
            transformStyle: "preserve-3d",
          }}
        >
          {/* Moving glow overlay */}
          <div
            className="absolute inset-0 pointer-events-none transition-opacity duration-300 opacity-0 group-hover:opacity-100 rounded-2xl"
            style={{
              background: `radial-gradient(circle at ${glowX}% ${glowY}%, ${service.color}20 0%, transparent 60%)`,
            }}
          />

          {/* Header gradient */}
          <div
            className="h-1 w-full relative z-10"
            style={{ background: `linear-gradient(90deg, ${service.color}, transparent)` }}
          />
          <div className="p-7 flex flex-col flex-1 relative z-10" style={{ transform: "translateZ(25px)", transformStyle: "preserve-3d" }}>
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300"
              style={{ background: `${service.color}12` }}
            >
              <service.icon className="w-7 h-7" style={{ color: service.color }} />
            </div>

            <div className="flex flex-col mb-3">
              <h3 className="text-xl font-bold text-white mb-1.5">{service.title}</h3>
              <div className="flex items-center gap-1.5 py-0.5 px-2 rounded bg-white/[0.03] border border-white/5 w-fit">
                <span className="text-[10px] text-[#AAB0BC] tracking-wider uppercase font-medium">Starting from</span>
                <span className="text-xs font-bold" style={{ color: service.color }}>{service.price}</span>
              </div>
            </div>
            <p className="text-sm text-[#AAB0BC] leading-relaxed mb-5">{service.desc}</p>

            {/* Features */}
            <button
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase mb-4"
              style={{ color: service.color }}
            >
              {expanded ? "Hide" : "Show"} Features
              {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            <AnimatePresence>
              {expanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden mb-5"
                >
                  <ul className="space-y-2.5">
                    {service.features.map((f, i) => (
                      <li key={i} className="flex items-center gap-2.5 text-sm text-[#AAB0BC]">
                        <Check className="w-3.5 h-3.5 flex-shrink-0" style={{ color: service.color }} />
                        {f}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="mt-auto pt-4 flex flex-wrap gap-3">
              <Link to="/contact" className="flex-1">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-3 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-2"
                  style={{ background: service.color }}
                >
                  Request Pricing
                  <ArrowRight className="w-3 h-3" />
                </motion.button>
              </Link>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function Services() {
  return (
    <div className="min-h-screen pt-24 md:pt-16 pb-32">
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full bg-[#0066FF]/5 blur-[120px]" />
        <div className="relative max-w-7xl mx-auto px-6">
          <SectionHeading
            badge="Our Services"
            title="Deploy the Right Solution for Your Business"
            description="Six core service pillars designed to cover every aspect of your business journey — from inception to digital transformation."
          />
        </div>
      </section>

      {/* Services grid */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <ServiceCard key={i} service={service} index={i} />
          ))}
        </div>
      </section>

      {/* Interactive Estimator */}
      <ServiceEstimator />

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-6 mt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass rounded-3xl p-10 md:p-14 text-center"
        >
          <h3 className="text-2xl md:text-3xl font-extrabold text-white mb-4">
            Not Sure What You Need?
          </h3>
          <p className="text-[#AAB0BC] mb-8 max-w-lg mx-auto">
            Let's discuss your business goals and we'll recommend the perfect solution package.
          </p>
          <Link to="/contact">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="px-8 py-4 bg-[#0066FF] rounded-xl text-sm font-semibold text-white inline-flex items-center gap-2 glow-blue"
            >
              Book a Free Consultation
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </Link>
        </motion.div>
      </section>
    </div>
  );
}