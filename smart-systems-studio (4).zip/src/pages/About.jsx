import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  Lightbulb,
  Shield,
  Award,
  Star,
  Heart,
  Target,
  Eye,
  ArrowRight,
  Zap,
} from "lucide-react";
import SectionHeading from "../components/shared/SectionHeading";
import AnimatedCounter from "../components/shared/AnimatedCounter";
import GlassCard from "../components/shared/GlassCard";

const values = [
  { icon: Lightbulb, title: "Innovation", desc: "Embracing cutting-edge technology to deliver future-proof solutions.", color: "#0066FF" },
  { icon: Shield, title: "Integrity", desc: "Building trust through transparency, honesty and ethical business practices.", color: "#00D4FF" },
  { icon: Award, title: "Professionalism", desc: "Delivering excellence in every interaction, every project, every time.", color: "#00FFB3" },
  { icon: Star, title: "Excellence", desc: "Setting the highest standards for quality across all our service offerings.", color: "#0066FF" },
  { icon: Heart, title: "Customer Success", desc: "Your growth is our purpose. We succeed only when you succeed.", color: "#00D4FF" },
];

const timeline = [
  { year: "2024", title: "The Vision", desc: "Smart Systems Studio was founded with a mission to democratize technology for African businesses." },
  { year: "2024", title: "First 100 Clients", desc: "Reached our first milestone — helping 100 businesses with registration and digital solutions." },
  { year: "2025", title: "Platform Launch", desc: "Launched our integrated business software suite, serving SMEs across South Africa." },
  { year: "2025", title: "Team Growth", desc: "Expanded our team of developers, designers and consultants to deliver at scale." },
  { year: "2026", title: "Digital Powerhouse", desc: "Recognized as a leading digital solutions provider with 450+ successful projects delivered." },
];

export default function About() {
  return (
    <div className="min-h-screen pt-24 md:pt-16 pb-32">
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute top-0 left-0 w-[600px] h-[400px] rounded-full bg-[#0066FF]/5 blur-[120px]" />
        <div className="relative max-w-7xl mx-auto px-6">
          <SectionHeading
            badge="About Us"
            title="Building Smarter Businesses Through Technology"
            description="Smart Systems Studio is on a mission to help entrepreneurs and companies across Africa launch, automate and scale their businesses with professional digital solutions."
          />
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="max-w-7xl mx-auto px-6 mb-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <GlassCard glowColor="rgba(0,102,255,0.12)" className="w-full">
            <div className="w-12 h-12 rounded-xl bg-[#0066FF]/10 flex items-center justify-center mb-5">
              <Target className="w-6 h-6 text-[#0066FF]" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Our Mission</h3>
            <p className="text-[#AAB0BC] leading-relaxed">
              To empower businesses of all sizes with affordable, professional and technology-driven solutions that simplify operations, accelerate growth and create lasting impact in the digital economy.
            </p>
          </GlassCard>

          <GlassCard glowColor="rgba(0,212,255,0.12)" className="w-full" delay={0.15}>
            <div className="w-12 h-12 rounded-xl bg-[#00D4FF]/10 flex items-center justify-center mb-5">
              <Eye className="w-6 h-6 text-[#00D4FF]" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Our Vision</h3>
            <p className="text-[#AAB0BC] leading-relaxed">
              To become Africa's leading digital business solutions provider — where every entrepreneur has access to world-class technology, design and business services regardless of their scale or budget.
            </p>
          </GlassCard>
        </div>
      </section>

      {/* Core Values */}
      <section className="max-w-7xl mx-auto px-6 mb-24">
        <SectionHeading
          badge="Our Values"
          title="What Drives Us"
          description="Our core values shape every decision, every solution and every relationship."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {values.map((v, i) => (
            <GlassCard key={i} delay={i * 0.1} glowColor={`${v.color}20`} className="h-full">
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center mb-4"
                style={{ background: `${v.color}12` }}
              >
                <v.icon className="w-5 h-5" style={{ color: v.color }} />
              </div>
              <h3 className="text-base font-bold text-white mb-2">{v.title}</h3>
              <p className="text-sm text-[#AAB0BC] leading-relaxed">{v.desc}</p>
            </GlassCard>
          ))}
        </div>
      </section>

      {/* Timeline */}
      <section className="max-w-4xl mx-auto px-6 mb-24">
        <SectionHeading badge="Our Journey" title="The Story So Far" />
        <div className="relative">
          {/* Line */}
          <div className="absolute left-6 md:left-1/2 md:-translate-x-px top-0 bottom-0 w-px bg-gradient-to-b from-[#0066FF] via-[#00D4FF] to-[#00FFB3]" />

          {timeline.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className={`relative flex items-start gap-6 mb-10 ${
                i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
              }`}
            >
              <div className="hidden md:block flex-1" />
              <div className="relative z-10 w-12 h-12 rounded-full glass flex items-center justify-center flex-shrink-0 glow-blue">
                <Zap className="w-4 h-4 text-[#00FFB3]" />
              </div>
              <GlassCard glowColor="rgba(0,212,255,0.08)" className="flex-1" delay={i * 0.1}>
                <div className="text-xs font-bold tracking-[0.2em] text-[#0066FF] uppercase mb-1">
                  {item.year}
                </div>
                <h4 className="text-base font-bold text-white mb-1">{item.title}</h4>
                <p className="text-sm text-[#AAB0BC] leading-relaxed">{item.desc}</p>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-6xl mx-auto px-6 mb-24">
        <GlassCard glowColor="rgba(0,255,179,0.1)" className="w-full">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-4 px-2">
            <AnimatedCounter target={280} suffix="+" label="Businesses Supported" />
            <AnimatedCounter target={452} suffix="+" label="Websites Built" />
            <AnimatedCounter target={650} suffix="+" label="Projects Completed" />
            <AnimatedCounter target={98} suffix="%" label="Client Satisfaction" />
          </div>
        </GlassCard>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <h3 className="text-2xl md:text-3xl font-extrabold text-white mb-4">
            Ready to Work With Us?
          </h3>
          <p className="text-[#AAB0BC] mb-8 max-w-lg mx-auto">
            Join hundreds of businesses that trust Smart Systems Studio for their digital transformation.
          </p>
          <Link to="/contact">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="px-8 py-4 bg-[#0066FF] rounded-xl text-sm font-semibold text-white inline-flex items-center gap-2 glow-blue"
            >
              Get in Touch
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </Link>
        </motion.div>
      </section>
    </div>
  );
}