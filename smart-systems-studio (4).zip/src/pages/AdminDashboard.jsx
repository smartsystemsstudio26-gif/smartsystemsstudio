import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, FileText, FileCheck, Settings,
  LogOut, Plus, Trash2, Printer, Mail,
  Phone, MapPin, Globe, Building2, Copy, Check,
  Calendar, Hash,
} from "lucide-react";

// ─── Business Defaults ────────────────────────────────────────────
const BUSINESS = {
  name: "Smart Systems Studio",
  tagline: "Digital Business Solutions",
  email: "info@smartsystemsstudio.co.za",
  phone: "+27 21 504 7780",
  address: "123 Innovation Drive, Century City",
  city: "Cape Town, 7441",
  country: "South Africa",
  website: "www.smartsystemsstudio.co.za",
  registration: "2024/123456/07",
  vat: "VAT Reg: 4920271234",
  bank: "Standard Bank",
  accountName: "Smart Systems Studio (Pty) Ltd",
  accountNumber: "10123456789",
  branchCode: "051001",
  swift: "SBZAZAJJ",
};

const TABS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "invoice", label: "Generate Invoice", icon: FileText },
  { id: "quotation", label: "Generate Quotation", icon: FileCheck },
  { id: "settings", label: "Business Settings", icon: Settings },
];

// ─── Sidebar ──────────────────────────────────────────────────────
function Sidebar({ activeTab, setActiveTab, onLogout }) {
  return (
    <div className="w-64 bg-[#0A0E1A] border-r border-white/5 flex flex-col min-h-screen">
      <div className="p-6 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#0066FF]/20 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-[#0066FF]" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white leading-tight">Smart Systems</h2>
            <p className="text-[10px] text-[#AAB0BC]/60">Admin Panel</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                isActive
                  ? "bg-[#0066FF]/15 text-white border border-[#0066FF]/20"
                  : "text-[#AAB0BC] hover:text-white hover:bg-white/5"
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/5">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-red-400 hover:bg-red-400/5 transition-all"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </div>
  );
}

// ─── Dashboard Overview ───────────────────────────────────────────
function DashboardOverview() {
  const stats = [
    { label: "Invoices Issued", value: "0", icon: FileText, color: "#0066FF" },
    { label: "Quotations Sent", value: "0", icon: FileCheck, color: "#00D4FF" },
    { label: "Active Clients", value: "0", icon: Building2, color: "#00FFB3" },
    { label: "This Month", value: "R 0.00", icon: Hash, color: "#a855f7" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-extrabold text-white mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass rounded-xl p-5 border border-white/5"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: s.color + "15" }}>
                <s.icon className="w-4 h-4" style={{ color: s.color }} />
              </div>
            </div>
            <p className="text-2xl font-bold text-white">{s.value}</p>
            <p className="text-xs text-[#AAB0BC] mt-1">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="glass rounded-xl p-6 border border-white/5 text-center">
        <p className="text-[#AAB0BC] text-sm">Welcome to your admin dashboard.</p>
        <p className="text-[#AAB0BC]/60 text-xs mt-1">Use the sidebar to generate invoices, quotations, and manage business settings.</p>
      </div>
    </div>
  );
}

// ─── Line Item Row ────────────────────────────────────────────────
function LineItemRow({ item, index, onChange, onRemove, currency }) {
  const total = (item.qty || 0) * (item.price || 0);
  return (
    <div className="grid grid-cols-12 gap-2 items-center">
      <div className="col-span-4">
        <input
          type="text"
          value={item.description}
          onChange={(e) => onChange(index, "description", e.target.value)}
          placeholder="Service / Product"
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder:text-[#AAB0BC]/40 focus:outline-none focus:border-[#0066FF]/50"
        />
      </div>
      <div className="col-span-2">
        <input
          type="number"
          value={item.qty}
          onChange={(e) => onChange(index, "qty", Math.max(1, parseInt(e.target.value) || 0))}
          min="1"
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white text-center focus:outline-none focus:border-[#0066FF]/50"
        />
      </div>
      <div className="col-span-3">
        <input
          type="number"
          value={item.price}
          onChange={(e) => onChange(index, "price", parseFloat(e.target.value) || 0)}
          min="0"
          step="0.01"
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white text-right focus:outline-none focus:border-[#0066FF]/50"
        />
      </div>
      <div className="col-span-2 text-right text-xs font-mono text-[#00FFB3]">
        {currency} {total.toLocaleString("en-ZA", { minimumFractionDigits: 2 })}
      </div>
      <div className="col-span-1 text-center">
        <button onClick={() => onRemove(index)} className="text-red-400 hover:text-red-300 transition-colors">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

// ─── Document Form (Invoice / Quotation) ─────────────────────────
function DocumentForm({ mode }) {
  const isInvoice = mode === "invoice";
  const title = isInvoice ? "Generate Invoice" : "Generate Quotation";
  const docLabel = isInvoice ? "Invoice" : "Quotation";
  const docPrefix = isInvoice ? "INV" : "QTN";
  const currency = "R";

  const [docNumber, setDocNumber] = useState(`${docPrefix}-${new Date().getFullYear()}-001`);
  const [docDate, setDocDate] = useState(new Date().toISOString().split("T")[0]);
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 14 * 86400000).toISOString().split("T")[0]
  );
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [clientAddress, setClientAddress] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [lineItems, setLineItems] = useState([
    { description: "", qty: 1, price: 0 },
  ]);
  const [note, setNote] = useState(isInvoice ? "Payment due within 14 days." : "Quotation valid for 30 days.");
  const [generated, setGenerated] = useState(false);
  const [copied, setCopied] = useState(false);

  const updateLineItem = (index, field, value) => {
    setLineItems((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const removeLineItem = (index) => {
    setLineItems((prev) => prev.filter((_, i) => i !== index));
  };

  const addLineItem = () => {
    setLineItems((prev) => [...prev, { description: "", qty: 1, price: 0 }]);
  };

  const subtotal = lineItems.reduce((sum, item) => sum + (item.qty || 0) * (item.price || 0), 0);
  const vatRate = 0.15;
  const vatAmount = subtotal * vatRate;
  const total = subtotal + vatAmount;

  const handleGenerate = () => {
    if (!clientName.trim()) return;
    setGenerated(true);
    // Scroll to preview
    setTimeout(() => {
      document.getElementById("doc-preview")?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleCopyDetails = () => {
    const docText = `
${BUSINESS.name}
${docLabel} #${docNumber}
─────────────────────────────
Date: ${docDate}${isInvoice ? `\nDue: ${dueDate}` : `\nValid Until: ${dueDate}`}
─────────────────────────────
Bill To:
${clientName}
${clientAddress}
${clientEmail}
${clientPhone}
─────────────────────────────
${lineItems.map((item, i) => `${i + 1}. ${item.description} — ${item.qty} × ${currency}${item.price.toFixed(2)} = ${currency}${(item.qty * item.price).toFixed(2)}`).join("\n")}
─────────────────────────────
Subtotal: ${currency}${subtotal.toFixed(2)}
VAT (15%): ${currency}${vatAmount.toFixed(2)}
TOTAL: ${currency}${total.toFixed(2)}
─────────────────────────────
${note}
─────────────────────────────
${BUSINESS.name}
${BUSINESS.address}, ${BUSINESS.city}
${BUSINESS.phone} | ${BUSINESS.email}
${BUSINESS.website}
`.trim();
    navigator.clipboard.writeText(docText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div>
      <h1 className="text-2xl font-extrabold text-white mb-6">{title}</h1>

      {/* Form */}
      <div className="glass rounded-xl p-6 border border-white/5 mb-8">
        {/* Doc Header */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-[#AAB0BC] mb-1">{docLabel} Number</label>
              <input
                type="text"
                value={docNumber}
                onChange={(e) => setDocNumber(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#0066FF]/50"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#AAB0BC] mb-1">Date</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#AAB0BC]/50" />
                <input
                  type="date"
                  value={docDate}
                  onChange={(e) => setDocDate(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-lg pl-10 pr-3 py-2 text-sm text-white focus:outline-none focus:border-[#0066FF]/50"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#AAB0BC] mb-1">
                {isInvoice ? "Due Date" : "Valid Until"}
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#AAB0BC]/50" />
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-lg pl-10 pr-3 py-2 text-sm text-white focus:outline-none focus:border-[#0066FF]/50"
                />
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="p-4 rounded-lg bg-[#0066FF]/5 border border-[#0066FF]/10">
              <h4 className="text-sm font-bold text-white mb-2">From</h4>
              <p className="text-sm text-white font-semibold">{BUSINESS.name}</p>
              <p className="text-xs text-[#AAB0BC]">{BUSINESS.address}, {BUSINESS.city}</p>
              <p className="text-xs text-[#AAB0BC]">{BUSINESS.phone}</p>
              <p className="text-xs text-[#AAB0BC]">{BUSINESS.email}</p>
              <p className="text-xs text-[#AAB0BC]">{BUSINESS.registration}</p>
            </div>
          </div>
        </div>

        {/* Client Details */}
        <div className="mb-6">
          <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#0066FF]" /> Bill To
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input
              type="text"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              placeholder="Client / Company Name *"
              required
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-[#AAB0BC]/40 focus:outline-none focus:border-[#0066FF]/50"
            />
            <input
              type="email"
              value={clientEmail}
              onChange={(e) => setClientEmail(e.target.value)}
              placeholder="Client Email"
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-[#AAB0BC]/40 focus:outline-none focus:border-[#0066FF]/50"
            />
            <input
              type="text"
              value={clientAddress}
              onChange={(e) => setClientAddress(e.target.value)}
              placeholder="Client Address"
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-[#AAB0BC]/40 focus:outline-none focus:border-[#0066FF]/50 md:col-span-2"
            />
            <input
              type="text"
              value={clientPhone}
              onChange={(e) => setClientPhone(e.target.value)}
              placeholder="Client Phone"
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-[#AAB0BC]/40 focus:outline-none focus:border-[#0066FF]/50"
            />
          </div>
        </div>

        {/* Line Items */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold text-white">Line Items</h4>
            <button
              onClick={addLineItem}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0066FF]/10 border border-[#0066FF]/20 text-[#0066FF] text-xs font-medium hover:bg-[#0066FF]/20 transition-all"
            >
              <Plus className="w-3 h-3" /> Add Item
            </button>
          </div>

          {/* Header row */}
          <div className="grid grid-cols-12 gap-2 mb-2 px-1">
            <span className="col-span-4 text-[10px] font-medium text-[#AAB0BC]/60 uppercase tracking-wider">Description</span>
            <span className="col-span-2 text-[10px] font-medium text-[#AAB0BC]/60 uppercase tracking-wider">Qty</span>
            <span className="col-span-3 text-[10px] font-medium text-[#AAB0BC]/60 uppercase tracking-wider">Price ({currency})</span>
            <span className="col-span-2 text-[10px] font-medium text-[#AAB0BC]/60 uppercase tracking-wider text-right">Total</span>
            <span className="col-span-1" />
          </div>

          <div className="space-y-2">
            {lineItems.map((item, i) => (
              <LineItemRow
                key={i}
                item={item}
                index={i}
                onChange={updateLineItem}
                onRemove={removeLineItem}
                currency={currency}
              />
            ))}
          </div>
        </div>

        {/* Note */}
        <div className="mb-6">
          <label className="block text-xs font-medium text-[#AAB0BC] mb-1">Notes / Terms</label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={2}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-[#AAB0BC]/40 focus:outline-none focus:border-[#0066FF]/50 resize-none"
          />
        </div>

        {/* Totals */}
        <div className="flex justify-end mb-6">
          <div className="w-72 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-[#AAB0BC]">Subtotal</span>
              <span className="text-white font-mono">{currency} {subtotal.toLocaleString("en-ZA", { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[#AAB0BC]">VAT (15%)</span>
              <span className="text-white font-mono">{currency} {vatAmount.toLocaleString("en-ZA", { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between text-base font-bold border-t border-white/10 pt-2">
              <span className="text-white">Total</span>
              <span className="text-[#00FFB3] font-mono">{currency} {total.toLocaleString("en-ZA", { minimumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleGenerate}
            disabled={!clientName.trim()}
            className="px-6 py-2.5 bg-[#0066FF] rounded-xl text-sm font-semibold text-white disabled:opacity-30 hover:bg-[#0055DD] transition-all flex items-center gap-2"
          >
            <FileText className="w-4 h-4" />
            Generate {docLabel}
          </button>
          {generated && (
            <>
              <button
                onClick={handlePrint}
                className="px-5 py-2.5 glass-light rounded-xl text-sm font-medium text-white hover:bg-white/10 transition-all flex items-center gap-2"
              >
                <Printer className="w-4 h-4" /> Print
              </button>
              <button
                onClick={handleCopyDetails}
                className="px-5 py-2.5 glass-light rounded-xl text-sm font-medium text-white hover:bg-white/10 transition-all flex items-center gap-2"
              >
                {copied ? <Check className="w-4 h-4 text-[#00FFB3]" /> : <Copy className="w-4 h-4" />}
                {copied ? "Copied" : "Copy"}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Preview */}
      <AnimatePresence>
        {generated && (
          <motion.div
            id="doc-preview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-8 md:p-10 shadow-2xl"
          >
            {/* Print styles */}
            <style>{`@media print { body * { visibility: hidden; } #doc-preview, #doc-preview * { visibility: visible; } #doc-preview { position: absolute; left: 0; top: 0; width: 100%; } }`}</style>

            {/* Document Header */}
            <div className="flex justify-between items-start mb-8 pb-6 border-b-2 border-gray-200">
              <div>
                <h2 className="text-2xl font-extrabold text-gray-900">{BUSINESS.name}</h2>
                <p className="text-sm text-gray-500 mt-1">{BUSINESS.tagline}</p>
                <div className="mt-3 space-y-0.5 text-xs text-gray-500">
                  <p className="flex items-center gap-1.5"><MapPin className="w-3 h-3" /> {BUSINESS.address}, {BUSINESS.city}</p>
                  <p className="flex items-center gap-1.5"><Phone className="w-3 h-3" /> {BUSINESS.phone}</p>
                  <p className="flex items-center gap-1.5"><Mail className="w-3 h-3" /> {BUSINESS.email}</p>
                  <p className="flex items-center gap-1.5"><Globe className="w-3 h-3" /> {BUSINESS.website}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="inline-block bg-[#0066FF] text-white px-5 py-3 rounded-xl mb-3">
                  <p className="text-lg font-extrabold tracking-wide">{docLabel.toUpperCase()}</p>
                </div>
                <p className="text-sm font-bold text-gray-900">#{docNumber}</p>
              </div>
            </div>

            {/* Dates & Client */}
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div>
                <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-3">Bill To</p>
                <p className="text-sm font-bold text-gray-900">{clientName}</p>
                {clientAddress && <p className="text-xs text-gray-600 mt-0.5">{clientAddress}</p>}
                {clientEmail && <p className="text-xs text-gray-600 mt-0.5">{clientEmail}</p>}
                {clientPhone && <p className="text-xs text-gray-600 mt-0.5">{clientPhone}</p>}
              </div>
              <div className="text-right">
                <div className="space-y-1.5">
                  <div className="flex justify-end gap-4 text-xs">
                    <span className="text-gray-500">Date:</span>
                    <span className="text-gray-900 font-medium">{docDate}</span>
                  </div>
                  <div className="flex justify-end gap-4 text-xs">
                    <span className="text-gray-500">{isInvoice ? "Due:" : "Valid Until:"}</span>
                    <span className="text-gray-900 font-medium">{dueDate}</span>
                  </div>
                </div>
                <div className="mt-3 text-xs text-gray-500">
                  <p>{BUSINESS.registration}</p>
                  <p>{BUSINESS.vat}</p>
                </div>
              </div>
            </div>

            {/* Line Items Table */}
            <table className="w-full mb-6">
              <thead>
                <tr className="border-b border-gray-300">
                  <th className="text-left text-[10px] font-semibold text-gray-400 uppercase tracking-wider pb-2">#</th>
                  <th className="text-left text-[10px] font-semibold text-gray-400 uppercase tracking-wider pb-2">Description</th>
                  <th className="text-center text-[10px] font-semibold text-gray-400 uppercase tracking-wider pb-2">Qty</th>
                  <th className="text-right text-[10px] font-semibold text-gray-400 uppercase tracking-wider pb-2">Price</th>
                  <th className="text-right text-[10px] font-semibold text-gray-400 uppercase tracking-wider pb-2">Total</th>
                </tr>
              </thead>
              <tbody>
                {lineItems.map((item, i) => (
                  <tr key={i} className="border-b border-gray-100">
                    <td className="py-2 text-xs text-gray-500">{i + 1}</td>
                    <td className="py-2 text-xs text-gray-900">{item.description || "—"}</td>
                    <td className="py-2 text-xs text-gray-900 text-center">{item.qty}</td>
                    <td className="py-2 text-xs text-gray-900 text-right font-mono">{currency} {item.price.toFixed(2)}</td>
                    <td className="py-2 text-xs text-gray-900 text-right font-mono">{currency} {(item.qty * item.price).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Totals */}
            <div className="flex justify-end mb-6">
              <div className="w-60">
                <div className="flex justify-between text-xs py-1.5">
                  <span className="text-gray-500">Subtotal</span>
                  <span className="text-gray-900 font-mono">{currency} {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs py-1.5">
                  <span className="text-gray-500">VAT (15%)</span>
                  <span className="text-gray-900 font-mono">{currency} {vatAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold py-2 border-t-2 border-gray-900 mt-1">
                  <span className="text-gray-900">TOTAL</span>
                  <span className="text-gray-900 font-mono">{currency} {total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Notes & Banking */}
            <div className="border-t border-gray-200 pt-4">
              <p className="text-xs text-gray-500">{note}</p>
              {isInvoice && (
                <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                  <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Banking Details</p>
                  <p className="text-xs text-gray-700"><strong>Bank:</strong> {BUSINESS.bank}</p>
                  <p className="text-xs text-gray-700"><strong>Account:</strong> {BUSINESS.accountName}</p>
                  <p className="text-xs text-gray-700"><strong>Account No:</strong> {BUSINESS.accountNumber}</p>
                  <p className="text-xs text-gray-700"><strong>Branch:</strong> {BUSINESS.branchCode} | <strong>SWIFT:</strong> {BUSINESS.swift}</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="text-center mt-6 pt-4 border-t border-gray-200">
              <p className="text-xs text-gray-400">{BUSINESS.name} &bull; {BUSINESS.phone} &bull; {BUSINESS.email}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Business Settings ────────────────────────────────────────────
function BusinessSettings() {
  const [settings, setSettings] = useState(BUSINESS);
  const [saved, setSaved] = useState(false);

  const handleChange = (field, value) => {
    setSettings((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    localStorage.setItem("business_settings", JSON.stringify(settings));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div>
      <h1 className="text-2xl font-extrabold text-white mb-6">Business Settings</h1>

      <div className="glass rounded-xl p-6 border border-white/5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {[
            { field: "name", label: "Business Name" },
            { field: "tagline", label: "Tagline" },
            { field: "email", label: "Email Address" },
            { field: "phone", label: "Phone Number" },
            { field: "address", label: "Street Address" },
            { field: "city", label: "City & Postal Code" },
            { field: "country", label: "Country" },
            { field: "website", label: "Website" },
            { field: "registration", label: "Company Registration" },
            { field: "vat", label: "VAT Number" },
            { field: "bank", label: "Bank Name" },
            { field: "accountName", label: "Account Holder" },
            { field: "accountNumber", label: "Account Number" },
            { field: "branchCode", label: "Branch Code" },
            { field: "swift", label: "SWIFT Code" },
          ].map(({ field, label }) => (
            <div key={field}>
              <label className="block text-xs font-medium text-[#AAB0BC] mb-1">{label}</label>
              <input
                type="text"
                value={settings[field]}
                onChange={(e) => handleChange(field, e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#0066FF]/50"
              />
            </div>
          ))}
        </div>

        <button
          onClick={handleSave}
          className="px-6 py-2.5 bg-[#0066FF] rounded-xl text-sm font-semibold text-white hover:bg-[#0055DD] transition-all flex items-center gap-2"
        >
          {saved ? <Check className="w-4 h-4 text-[#00FFB3]" /> : <Settings className="w-4 h-4" />}
          {saved ? "Saved!" : "Save Settings"}
        </button>
      </div>
    </div>
  );
}

// ─── Main Admin Dashboard ─────────────────────────────────────────
export default function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("dashboard");

  useEffect(() => {
    const session = localStorage.getItem("admin_session");
    if (session !== "authenticated") {
      navigate("/admin/login", { replace: true });
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("admin_session");
    navigate("/admin/login", { replace: true });
  };

  return (
    <div className="flex min-h-screen bg-[#050816]">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} />
      <main className="flex-1 p-6 md:p-8 overflow-auto max-h-screen">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === "dashboard" && <DashboardOverview />}
            {activeTab === "invoice" && <DocumentForm mode="invoice" />}
            {activeTab === "quotation" && <DocumentForm mode="quotation" />}
            {activeTab === "settings" && <BusinessSettings />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}