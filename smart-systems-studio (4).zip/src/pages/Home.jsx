import React from "react";
import HeroSection from "../components/home/HeroSection";
import StatsSection from "../components/home/StatsSection";
import ServiceEstimator from "../components/estimator/ServiceEstimator";
import TransformationSection from "../components/home/TransformationSection";
import WhyChooseUs from "../components/home/WhyChooseUs";
import TestimonialsSection from "../components/home/TestimonialsSection";
import CTASection from "../components/home/CTASection";

export default function Home() {
  return (
    <div>
      <HeroSection />
      <StatsSection />
      <TransformationSection />
      <ServiceEstimator />
      <WhyChooseUs />
      <TestimonialsSection />
      <CTASection />
    </div>
  );
}