import { useMemo } from "react";

const currencyMap = {
  ZA: { code: "ZAR", symbol: "R", locale: "en-ZA" },
  NG: { code: "NGN", symbol: "₦", locale: "en-NG" },
  KE: { code: "KES", symbol: "KSh", locale: "en-KE" },
  GH: { code: "GHS", symbol: "GH₵", locale: "en-GH" },
  TZ: { code: "TZS", symbol: "TSh", locale: "en-TZ" },
  UG: { code: "UGX", symbol: "USh", locale: "en-UG" },
  US: { code: "USD", symbol: "$", locale: "en-US" },
  GB: { code: "GBP", symbol: "£", locale: "en-GB" },
  EU: { code: "EUR", symbol: "€", locale: "en-IE" },
  IN: { code: "INR", symbol: "₹", locale: "en-IN" },
  CA: { code: "CAD", symbol: "CA$", locale: "en-CA" },
  AU: { code: "AUD", symbol: "A$", locale: "en-AU" },
  AE: { code: "AED", symbol: "د.إ", locale: "en-AE" },
  SA: { code: "SAR", symbol: "﷼", locale: "en-SA" },
};

const defaultCurrency = { code: "USD", symbol: "$", locale: "en-US" };

export function useCurrency() {
  const currency = useMemo(() => {
    try {
      const locale = navigator.language || "en-US";
      // Get currency from locale
      const parts = new Intl.NumberFormat(locale, { style: "currency", currency: "USD" }).formatToParts(1);
      const currencyPart = parts.find(p => p.type === "currency");
      if (currencyPart) {
        return {
          code: currencyPart.value,
          symbol: new Intl.NumberFormat(locale, { style: "currency", currency: currencyPart.value, currencyDisplay: "narrowSymbol" }).formatToParts(0).find(p => p.type === "currency")?.value || currencyPart.value,
          locale,
        };
      }
    } catch {}
    return defaultCurrency;
  }, []);

  const formatPrice = (amount) => {
    try {
      return new Intl.NumberFormat(currency.locale, {
        style: "currency",
        currency: currency.code,
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(amount);
    } catch {
      return `${currency.symbol}${amount}`;
    }
  };

  return { currency, formatPrice };
}